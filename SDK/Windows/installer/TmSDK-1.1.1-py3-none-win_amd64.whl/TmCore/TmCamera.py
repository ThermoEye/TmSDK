import traceback
import os, sys
from ctypes import *
from .TmException import *
from . import libTmCore
from .TmFrame import *
from .TmControl import *

class TmLocalCamInfoStructure(Structure):
    _fields_ = [("name", c_char_p),
                ("com_port", c_char_p),
                ("index", c_int)]

class TmRemoteCamInfoStructure(Structure):
    _fields_ = [("name", c_char_p),
                ("serial_number", c_char_p),
                ("mac", c_char_p),
                ("ip", c_char_p)]
    
class TmLocalCamInfo(object):
    ### <summary>
    ### Initializes a new instance of the <c>TmLocalCamInfo</c> class.
    ### </summary>
    ### <param name="obj">A pointer to the native local camera object.</param>
    def __init__(self, obj):
        self.obj = obj
        
    ### <summary>
    ### Retrieves the name of the local camera.
    ### </summary>
    ### <returns>
    ### A string representing the name of the local camera.
    ### </returns>
    def get_local_camera_name(self):
        func = libTmCore.TmCamera_GetLocalCameraName
        func.argtypes = [c_void_p]
        func.restype = c_char_p
        name = func(self.obj)
        return name
    
    ### <summary>
    ### Retrieves the COM port associated with the local camera.
    ### </summary>
    ### <returns>
    ### A string representing the COM port of the local camera.
    ### </returns>
    def get_local_camera_com_port(self):
        func = libTmCore.TmCamera_GetLocalCameraComPort
        func.argtypes = [c_void_p]
        func.restype = c_char_p
        com_port = func(self.obj)
        return com_port
    
    ### <summary>
    ### Retrieves the index of the local camera.
    ### </summary>
    ### <returns>
    ### An integer representing the index of the local camera.
    ### </returns>
    def get_local_camera_index(self):
        func = libTmCore.TmCamera_GetLocalCameraIndex
        func.argtypes = [c_void_p]
        func.restype = c_int
        index = func(self.obj)
        return index

class TmRemoteCamInfo(object):
    ### <summary>
    ### Initializes a new instance of the <c>TmRemoteCamInfo</c> class.
    ### </summary>
    ### <param name="obj">A pointer to the native remote camera object.</param>
    def __init__(self, obj):
        self.obj = obj
        
    ### <summary>
    ### Retrieves the name of the remote camera.
    ### </summary>
    ### <returns>
    ### A string representing the name of the remote camera.
    ### </returns>
    def get_remote_camera_name(self):
        func = libTmCore.TmCamera_GetRemoteCameraName
        func.argtypes = [c_void_p]
        func.restype = c_char_p
        name = func(self.obj)
        return name
    
    ### <summary>
    ### Retrieves the serial number of the remote camera.
    ### </summary>
    ### <returns>
    ### A string representing the serial number of the remote camera.
    ### </returns>
    def get_remote_camera_serial_number(self):
        func = libTmCore.TmCamera_GetRemoteCameraSerialNumber
        func.argtypes = [c_void_p]
        func.restype = c_char_p
        serial_number = func(self.obj)
        return serial_number
    
    ### <summary>
    ### Retrieves the MAC address of the remote camera.
    ### </summary>
    ### <returns>
    ### A string representing the MAC address of the remote camera.
    ### </returns>
    def get_remote_camera_mac(self):
        func = libTmCore.TmCamera_GetRemoteCameraMac
        func.argtypes = [c_void_p]
        func.restype = c_char_p
        mac = func(self.obj)
        return mac
    
    ### <summary>
    ### Retrieves the IP address of the remote camera.
    ### </summary>
    ### <returns>
    ### A string representing the IP address of the remote camera.
    ### </returns>
    def get_remote_camera_ip(self):
        func = libTmCore.TmCamera_GetRemoteCameraIp
        func.argtypes = [c_void_p]
        func.restype = c_char_p
        ip = func(self.obj)
        return ip
    
### <summary>
### Represents a remote thermal camera that can be controlled and queried for information.
### This class extends the base <c>TmCamera</c> class and provides additional functionality specific to remote cameras.
### It includes methods for initializing a remote camera instance and retrieving a list of available remote cameras.
### </summary>
class TmCamera(object):
    ### <summary>
    ### Creates a new instance of the <c>TmCamera</c> class.
    ### </summary>
    def __init__(self):
        #self.obj = None
        self.obj = c_void_p()
        self.tmControl = None
    
    ### <summary>
    ### Destroys an instance of the <c>TmCamera</c> class, releasing any resources associated with it.
    ### </summary>
    def __del__(self):
       if self.obj is not None:
           func = libTmCore.TmCamera_Dtor
           func.argtypes = [c_void_p]
           func.restype = None
           func(self.obj)
        
    ### <summary>
    ### Enumeration of local cameras
    ### </summary>
    ### <returns>
    ### A tuple containing:
    ###    - names: A list of strings, where each string is the name of a camera.
    ###    - ports: A list of strings, where each string is the port associated with a camera.
    ###    - indexes: A list of integers, where each integer is the index of a camera.
    ###    - count: The number of cameras retrieved (up to the specified maximum count).
    ### </returns>
    @staticmethod
    def get_local_camera_list():
        func = libTmCore.TmCamera_GetLocalCameraList
        func.argtypes = [POINTER(POINTER(POINTER(TmLocalCamInfoStructure)))]
        func.restype = c_int
        
        list_ptr = POINTER(POINTER(TmLocalCamInfoStructure))()
        count = func(byref(list_ptr))
        
        camera_list = [list_ptr[i] for i in range(count)]
        names = []
        ports = []
        indexes = []
        for i in range(count):
            info = TmLocalCamInfo(camera_list[i])
            name = info.get_local_camera_name()
            com_port = info.get_local_camera_com_port()
            index = info.get_local_camera_index()
            names.append(name.decode('utf-8'))
            ports.append(com_port.decode('utf-8'))
            indexes.append(index)
            
        return names, ports, indexes, count
    
    ### <summary>
    ### Enumeration of remote cameras
    ### </summary>
    ### <returns>
    ### A tuple containing:
    ###    - names: A list of strings, where each string is the name of a remote camera.
    ###    - serials: A list of strings, where each string is the serial number of a remote camera.
    ###    - macs: A list of strings, where each string is the MAC address of a remote camera.
    ###    - ips: A list of strings, where each string is the IP address of a remote camera.
    ###    - count: The number of cameras retrieved (up to the specified maximum count).
    ### </returns>
    @staticmethod
    def get_remote_camera_list():
        func = libTmCore.TmCamera_GetRemoteCameraList
        func.argtypes = [POINTER(POINTER(POINTER(TmRemoteCamInfoStructure)))]
        func.restype = c_int
        
        list_ptr = POINTER(POINTER(TmRemoteCamInfoStructure))()
        count = func(byref(list_ptr))
        
        camera_list = [list_ptr[i] for i in range(count)]
        names = []
        serial_numbers = []
        macs = []
        ips = []
        for i in range(count):
            info = TmRemoteCamInfo(camera_list[i])
            name = info.get_remote_camera_name()
            serial_number = info.get_remote_camera_serial_number()
            mac = info.get_remote_camera_mac()
            ip = info.get_remote_camera_ip()
            names.append(name.decode('utf-8'))
            serial_numbers.append(serial_number.decode('utf-8'))
            macs.append(mac.decode('utf-8'))
            ips.append(ip.decode('utf-8'))
            
        return names, serial_numbers, macs, ips, count
    

    ### <summary>
    ### Retrieves the TmControl object associated with the camera.
    ### </summary>
    ### <returns>
    ### A pointer to the TmControl object.
    ### </returns>
    def get_TmControl(self):
        func = libTmCore.TmCamera_GetTmControl 
        func.argtypes = [c_void_p]
        func.restype = c_void_p
        return func(self.obj)

    ### <summary>
    ### Opens a local camera connection with the specified parameters.
    ### </summary>
    ### <param name="name">The name of the camera to open.</param>
    ### <param name="comPort">The serial port associated with the camera.</param>
    ### <param name="index">The index of the camera.</param>
    ### <returns>
    ### A boolean indicating whether the camera was successfully opened.
    ### Returns `True` if the camera was successfully opened, otherwise `False`.
    ### </returns>
    def open_local_camera(self, name, comPort, index):
        if self.obj is None:
           return False
        func = libTmCore.TmCamera_CtorLocal
        func.argtypes = ()
        func.restype = c_void_p
        self.obj = func()
        if self.obj is None:
            return False
        func = libTmCore.TmCamera_LocalOpen
        func.argtypes = [c_void_p, POINTER(c_bool), c_char_p, c_char_p, c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), name.encode('utf-8'), comPort.encode('utf-8'), index))
        if ret.value == True:
           self.tmControl = TmControl(self.get_TmControl())
        return ret.value

    ### <summary>
    ### Opens a remote camera connection with the specified parameters.
    ### </summary>
    ### <param name="name">The name of the camera to open.</param>
    ### <param name="serialnumber">The serial number of the remote camera.</param>
    ### <param name="mac">The MAC address of the remote camera.</param>
    ### <param name="ip">The IP address of the remote camera.</param>
    ### <returns>
    ### A boolean indicating whether the remote camera was successfully opened.
    ### Returns `True` if the camera was successfully opened, otherwise `False`.
    ### </returns>
    def open_remote_camera(self, name, serialnumber, mac, ip):
        func = libTmCore.TmCamera_CtorRemote
        func.argtypes = ()
        func.restype = c_void_p
        self.obj = func()
        if self.obj is None:
            return False            
        func = libTmCore.TmCamera_RemoteOpen
        func.argtypes = [c_void_p, POINTER(c_bool), c_char_p, c_char_p, c_char_p, c_char_p]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), name.encode('utf-8'), serialnumber.encode('utf-8'), mac.encode('utf-8'), ip.encode('utf-8')))
        if ret.value == True:
           self.tmControl = TmControl(self.get_TmControl())
        return ret.value
    
    ### <summary>
    ### Queries a frame from the camera with the specified width and height.
    ### </summary>
    ### <param name="width">The desired width of the frame.</param>
    ### <param name="height">The desired height of the frame.</param>
    ### <returns>
    ### A `TmFrame` object representing the queried frame if successful.
    ### Returns `None` if the frame could not be queried.
    ### </returns>
    def query_frame(self, width, height):
        func = libTmCore.TmCamera_QueryFrame
        func.argtypes = [c_void_p, POINTER(c_bool), c_void_p, c_int, c_int]
        func.restype = c_void_p
        ret = c_bool(False)
        frame = TmFrame()
        func(self.obj, pointer(ret), frame.obj, width, height)
        if ret.value == False:
            del frame
            frame = None    
        return frame
    
    ### <summary>
    ### Closes the connection to the camera and releases resources.
    ### </summary>
    ### <returns>
    ### `True` if the camera was successfully closed and resources were released.
    ### `False` otherwise.
    ### </returns>      
    def close(self):
        func = libTmCore.TmCamera_Close
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        if ret == True:
            self.tmControl = None
        return ret.value
    
    ### <summary>
    ### Retrieves the temperature unit symbol based on the current temperature unit setting.
    ### </summary>
    ### <returns>
    ### A string representing the temperature unit symbol:
    ### - '��' for Celsius
    ### - '��' for Fahrenheit
    ### - 'K' for Kelvin
    ### </returns>
    def get_temp_unit_symbol(self):
        func = libTmCore.TmCamera_GetTempUnit
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        temp_unit_symbol = ''
        if arg.value == TempUnit.CELSIUS:
            temp_unit_symbol = b'\xe2\x84\x83'.decode('utf-8')
        elif arg.value == TempUnit.FAHRENHEIT:
            temp_unit_symbol = b'\xe2\x84\x89'.decode('utf-8')
        elif arg.value == TempUnit.KELVIN:
            temp_unit_symbol = 'K'
        return temp_unit_symbol
    
    ### <summary>
    ### Retrieves the current temperature unit setting from the camera.
    ### </summary>
    ### <returns>
    ### An integer representing the temperature unit:
    ### - `TempUnit.CELSIUS` (value 0) for Celsius
    ### - `TempUnit.FAHRENHEIT` (value 1) for Fahrenheit
    ### - `TempUnit.KELVIN` (value 2) for Kelvin
    ### The exact values depend on the enumeration defined in the library.
    ### </returns>
    def get_temp_unit(self):
        func = libTmCore.TmCamera_GetTempUnit
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return arg.value
    
    ### <summary>
    ### Sets the temperature unit for the camera.
    ### </summary>
    ### <param name="arg">
    ### An integer representing the temperature unit to set:
    ### - `TempUnit.RAW` (value 0) for Raw data
    ### - `TempUnit.CELSIUS` (value 1) for Celsius
    ### - `TempUnit.FAHRENHEIT` (value 2) for Fahrenheit
    ### - `TempUnit.KELVIN` (value 3) for Kelvin
    ### </param>
    ### <returns>
    ### A boolean value indicating whether the operation was successful.
    ### - `True` if the temperature unit was successfully set.
    ### - `False` otherwise.
    ### </returns>
    def set_temp_unit(self, arg):
        func = libTmCore.TmCamera_SetTempUnit
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value

    ### <summary>
    ### Retrieves the temperature value in the current unit from a raw temperature reading.
    ### </summary>
    ### <param name="raw">
    ### A floating-point number representing the raw temperature value to be converted.
    ### </param>
    ### <returns>
    ### The converted temperature value in the current unit (Celsius, Fahrenheit, or Kelvin).
    ### </returns>
    def get_temperature(self, raw):
        func = libTmCore.TmCamera_GetTemperature
        func.argtypes = [c_void_p, POINTER(c_bool), c_double, POINTER(c_double)]
        func.restype = c_char_p
        ret = c_bool(False)
        raw_value = c_double(raw)
        result = c_double(0.0)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), raw_value, pointer(result)))
        return result.value 
    
    ### <summary>
    ### Sets the color map for the camera.
    ### </summary>
    ### <param name="arg">
    ### An integer representing the color map to be set. The specific values depend on the camera's supported color maps.
    ### </param>
    ### <returns>
    ### A boolean value indicating the success or failure of the operation. Returns True if the color map was successfully set, otherwise False.
    ### </returns>
    def set_color_map(self, arg):
        func = libTmCore.TmCamera_SetColorMap
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    
    ### <summary>
    ### Configures the noise filtering setting for the camera.
    ### </summary>
    ### <param name="arg">
    ### A boolean value indicating whether noise filtering should be enabled or disabled. `True` to enable, `False` to disable.
    ### </param>
    ### <returns>
    ### A boolean value indicating the success or failure of the operation. Returns `True` if the noise filtering setting was successfully applied, otherwise `False`.
    ### </returns>
    def set_noise_filtering(self, arg):
        func = libTmCore.TmCamera_SetNoiseFiltering
        func.argtypes = [c_void_p, POINTER(c_bool), c_bool]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    
    def get_api_version(self):
        func = libTmCore.TmCamera_GetAPIVersion
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 12)]
        func.restype = c_char_p
        ret = c_bool(False)
        version = create_string_buffer(12)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), version))
        
        if not ret.value:
            return None
        return version.value.decode(sys.getdefaultencoding())

    
        