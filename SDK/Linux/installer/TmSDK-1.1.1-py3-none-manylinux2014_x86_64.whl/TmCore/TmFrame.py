import os, sys
from ctypes import *
from .TmException import *
from .TmTypes import *
from . import libTmCore

### <summary>
### TmFrame
### </summary>
class TmFrame(object):
    ### <summary>
    ### Creates a new instance of the <c>TmFrame</c> class.
    ### </summary>
    def __init__(self):
        func = libTmCore.TmFrame_Ctor
        func.argtypes = ()
        func.restype = c_void_p
        self.obj = func()
      
    ### <summary>
    ### Destroys an instance of the <c>TmFrame</c> class, releasing any resources associated with it.
    ### </summary>
    def __del__(self):
        func = libTmCore.TmFrame_Dtor
        func.argtypes = [c_void_p]
        func.restype = None
        func(self.obj)

    ### <summary>
    ### Converts a frame to a bitmap image in memory.
    ### </summary>
    ### <param name="colorOrder">
    ### An integer representing the color order used in the bitmap conversion. 
    ### This is typically used to specify the color format, such as RGB or BGR.
    ###  ColorOrder.COLOR_BGR = 0
    ###  ColorOrder.COLOR_RGB = 1    
    ### </param>
    ### <returns>
    ### A byte string representing the bitmap image. The byte string will contain raw image data in the specified color order, with each pixel represented by 3 bytes (one for each color channel).
    ### </returns>
    def to_bitmap(self, colorOrder):
        func = libTmCore.TmFrame_ToBitMap
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = POINTER(c_ubyte)
        width = self.width()
        height = self.height()
        ret = c_bool(False)
        pData = func(self.obj, pointer(ret), colorOrder)
        return bytes(pData[:width * height * 3])
    
    ### <summary>
    ### Retrieves the width of the frame.
    ### </summary>
    ### <returns>
    ### The width of the frame as an integer. Returns `None` if the width could not be retrieved.
    ### </returns>
    def width(self):
        func = libTmCore.TmFrame_Width
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_void_p
        ret = c_bool(False)
        val = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(val)))
        if ret is False:
            return None      
        return val.value
    
    ### <summary>
    ### Retrieves the height of the frame.
    ### </summary>
    ### <returns>
    ### The height of the frame as an integer. Returns `None` if the height could not be retrieved.
    ### </returns>
    def height(self):
        func = libTmCore.TmFrame_Height
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_void_p
        ret = c_bool(False)
        val = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(val)))
        if ret is False:
            return None      
        return val.value

    ### <summary>
    ### Retrieves the minimum, average, and maximum values from the frame, along with their locations.
    ### </summary>
    ### <returns>
    ### A tuple containing:
    ### - `minVal`: The minimum value found in the frame.
    ### - `avgVal`: The average value of the frame.
    ### - `maxVal`: The maximum value found in the frame.
    ### - `minLoc`: A `Point` object representing the location of the minimum value.
    ### - `maxLoc`: A `Point` object representing the location of the maximum value.
    ### 
    ### Returns `None` if the operation fails.
    ### </returns>
    def min_max_loc(self):
        func = libTmCore.TmFrame_MinMaxLoc
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_double), POINTER(c_double), POINTER(c_double), POINTER(Point), POINTER(Point)]
        func.restype = c_void_p

        ret = c_bool(False)
        minVal = c_double(-1.0)
        avgVal = c_double(-1.0)
        maxVal = c_double(-1.0)
        minLoc = Point()
        maxLoc = Point()
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(minVal), pointer(avgVal), pointer(maxVal), pointer(minLoc), pointer(maxLoc)))
        if ret is False:
            return None
        return minVal.value, avgVal.value, maxVal.value, minLoc, maxLoc
    
    ### <summary>
    ### Performs a measurement operation on the frame using a specified region of interest (ROI).
    ### </summary>
    ### <param name="roi_item">
    ### The object in the area you want to measure.
    ### </param>
    ### <returns>
    ### A boolean value indicating whether the resource release was successful.
    ### Returns `True` if the measurement was successful; `False` otherwise.
    ### </returns>
    def do_measure(self, roi_item):
        func = libTmCore.TmFrame_DoMeasure
        func.argtypes = [c_void_p, POINTER(c_bool), c_void_p]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), roi_item.obj))
        return ret.value
            
    ### <summary>
    ### Releases the resources associated with the frame object.
    ### </summary>
    ### <returns>
    ### A boolean value indicating whether the resource release was successful.
    ### Returns `True` if the release was successful; `False` otherwise.
    ### </returns>
    def release(self):
        func = libTmCore.TmFrame_Release
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
      