import os, sys
from ctypes import *
import math
from .TmException import *
from . import libTmCore

class TmControl(object):
    def __init__(self, object = None):
        self.obj = object if object is not None else c_void_p()  # obj if obj is not None else c_void_p()
    
    ### <summary>
    ### Retrieves the gain mode state from the camera.
    ### </summary>
    ### <returns>
    ### A tuple containing:
    ### - A boolean value indicating the success or failure of the gain mode state retrieval.
    ### - An integer representing the current gain mode state.
    ### 
    ### If the function fails to retrieve the gain mode state, it raises a `TmException` with the error message.
    ### </returns>
    def get_gain_mode_state(self):
        func = libTmCore.TmCtrl_GetGainModeState
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        gain_mode = c_int(0)
        result = func(self.obj, byref(ret), pointer(gain_mode))
        if result:
            error_message = result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value, gain_mode.value
    
    ### <summary>
    ### Sets the gain mode state for the camera.
    ### </summary>
    ### <param name="gain_mode">An integer value representing the desired gain mode state to set.</param>
    ### <returns>
    ### A boolean value indicating the success or failure of setting the gain mode state.
    ### 
    ### If the function fails to set the gain mode state, it raises a `TmException` with the error message.
    ### </returns>
    def set_gain_mode_state(self, gain_mode):
        func = libTmCore.TmCtrl_SetGainModeState
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        result = func(self.obj,byref(ret), c_int(gain_mode))
        if result:
            error_message = result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    
    ### <summary>
    ### Retrieves the product model name of the camera.
    ### </summary>
    ### <returns>
    ### A string representing the product model name of the camera.
    ### 
    ### If the function fails to retrieve the product model name, it returns `None`.
    ### </returns>      
    def get_product_model_name(self):
        func = libTmCore.TmCtrl_GetProductModelName
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        arg = create_string_buffer(255)
        ret = c_bool(False)
        try:
            result = func(self.obj, pointer(ret), arg)
            TmException.ExceptionHandler(result)
        except Exception as e:
            print(f"Error in get_product_model_name: {e}")
            return None
        if not ret.value:
            return None
        return arg.value.decode(sys.getdefaultencoding())
    
    ### <summary>
    ### Retrieves the current state of the flat field correction mode of the camera.
    ### </summary>
    ### <returns>
    ### A tuple containing:
    ###   - A boolean indicating whether the operation was successful.
    ###   - An integer representing the current flat field correction mode.
    ### 
    ### </returns>
    def get_flat_field_correction_mode(self):
        func = libTmCore.TmCtrl_GetFlatFieldCorrectionMode
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = c_int(0)
        TmException.ExceptionHandler(func(self.obj, byref(ret), byref(arg)))
        return ret.value, arg.value
    
    ### <summary>
    ### Retrieves the flat field correction parameters from the camera.
    ### </summary>
    ### <returns>
    ### A tuple containing:
    ###   - A boolean indicating whether the operation was successful.
    ###   - A double representing the maximum interval for flat field correction.
    ###   - A double representing the auto-trigger threshold for flat field correction.
    ### 
    ### </returns>
    def get_flat_feild_correction_parameters(self):
        func=libTmCore.TmCtrl_GetFlatFieldCorrectionParameters
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_double), POINTER(c_double)]
        func.restype = c_char_p
        ret = c_bool(False)
        max_interval = c_double(0)
        auto_trigger_threshold = c_double(0)
        TmException.ExceptionHandler(func(self.obj, byref(ret), pointer(max_interval), pointer(auto_trigger_threshold)))
        return ret.value, max_interval.value, auto_trigger_threshold.value
    
    ### <summary>
    ### Sets the flat field correction parameters for the camera.
    ### </summary>
    ### <param name="maxInterval">The maximum interval for flat field correction. It should be a double value.</param>
    ### <param name="autoTriggerThreshold">The auto-trigger threshold for flat field correction. It should be a double value.</param>
    ### <returns>
    ### A boolean indicating whether the operation was successful.
    ### 
    ### </returns>
    def set_flat_feild_correction_parameters(self,maxInterval,autoTriggerThreshold):
        func = libTmCore.TmCtrl_SetFlatFieldCorrectionParameters
        func.argtypes = [c_void_p, POINTER(c_bool), c_double, c_double]
        func.restype = c_char_p
        ret = c_bool(False)
        result = func(self.obj,byref(ret), c_double(maxInterval), c_double(autoTriggerThreshold))
        if result:
            error_message=result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    
    ### <summary>
    ### Executes the flat field correction process on the camera.
    ### </summary>
    ### <returns>
    ### A boolean indicating whether the flat field correction operation was successful.
    ### 
    ### </returns>
    def run_flat_field_correction(self):
        func = libTmCore.TmCtrl_RunFlatFieldCorrection
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        result = func(self.obj,byref(ret))
        if result:
            error_message = result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value

    ### <summary>
    ### Retrieves the flux parameters for the camera's measurement system.
    ### </summary>
    ### <param name="sceneEmissivity">The emissivity of the scene. <br>
    ### Range : 0.01 ~ 1.00
    ### </param>
    ### <param name="atmosphericTransmission">The atmospheric transmission factor. <br>
    ### Range : 0.01 ~ 1.00</param>
    ### <param name="atmosphericTemperature">The temperature of the atmosphere. <br>
    ### Range(TMC80,TMC160) : -273.15 ~ 382.2 <br>
    ### Range(TMC256) : -43.15 ~ 626.85</param>
    ### <param name="windowReflectedTemperature">The temperature of the reflected window. <br>
    ### Range(TMC80,TMC160) : -273.15 ~ 382.2 <br>
    ### Range(TMC256) : -43.15 ~ 626.85</param>
    ### <param name="windowReflection">The reflection factor of the window. <br>
    ### For TMC256, this value means 'distance'. <br>
	### Range : 0.00 ~ 0.00
    ### </param>
    ### <param name="backgroundTemperature">Optional background temperature. <br>
    ### Range : -273.15 ~ 382.2 <br>
	### For TMC256, initialize this value to NaN.
    ### </param>
    ### <param name="windowTransmission">Optional window transmission factor. <br>
    ### Range : 0.01 ~ 1.00 <br>
	### For TMC256, initialize this value to NaN.
    ### </param>
    ### <param name="windowTemperature">Optional window temperature. <br>
    ### Range : -273.15 ~ 382.2 <br>
	### For TMC256, initialize this value to NaN.
    ### </param>
    ### <returns>
    ### A dictionary containing the flux parameters. The dictionary will include:
    ### - scene_emissivity: The emissivity of the scene.
    ### - atmospheric_transmission: The atmospheric transmission factor.
    ### - atmospheric_temperature: The temperature of the atmosphere.
    ### - window_reflected_temperature: The temperature of the reflected window.
    ### - window_reflection: The reflection factor of the window.
    ### 
    ### If TMC80, TMC160, the dictionary will also include:
    ### - background_temperature: The background temperature.
    ### - window_transmission: The window transmission factor.
    ### - window_temperature: The window temperature.
    ### 
    ### </returns>
    def get_flux_parameters(self, sceneEmissivity, atmosphericTransmission, atmosphericTemperature, 
                            windowReflectedTemperature, windowReflection, backgroundTemperature = math.nan,
                           windowTransmission = math.nan, windowTemperature = math.nan): 
        func = libTmCore.TmCtrl_GetFluxParameters
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_double), POINTER(c_double), POINTER(c_double)
                         , POINTER(c_double), POINTER(c_double), POINTER(c_double), POINTER(c_double), POINTER(c_double)]
        func.restype = c_char_p
        ret = c_bool(False)
        tmc256 = c_bool(False)
        sceneEmissivity = c_double(sceneEmissivity)
        atmosphericTransmission = c_double(atmosphericTransmission)
        atmosphericTemperature = c_double(atmosphericTemperature)
        windowReflectedTemperature = c_double(windowReflectedTemperature)
        windowReflection = c_double(windowReflection)
    
        if math.isnan(backgroundTemperature) or math.isnan(windowTransmission) or math.isnan(windowTemperature):
            backgroundTemperature = c_double(math.nan)
            windowTransmission = c_double(math.nan)
            windowTemperature = c_double(math.nan)
            tmc256 = c_bool(True)
        else:
            backgroundTemperature = c_double(backgroundTemperature)
            windowTransmission = c_double(windowTransmission)
            windowTemperature = c_double(windowTemperature)
        
        result = func(
            self.obj,
            pointer(ret),
            pointer(sceneEmissivity),
            pointer(atmosphericTransmission),
            pointer(atmosphericTemperature),
            pointer(windowReflectedTemperature),
            pointer(windowReflection),
            pointer(backgroundTemperature),
            pointer(windowTransmission),
            pointer(windowTemperature)
        )

        if result:
            error_message = result.decode(sys.getdefaultencoding())
            raise TmException(error_message)

        if not ret.value:
            print("TmCtrl_GetFluxParameters failed!")
            return None

        if tmc256:
            return {
                "scene_emissivity": sceneEmissivity.value,
                "atmospheric_transmission": atmosphericTransmission.value,
                "atmospheric_temperature": atmosphericTemperature.value,
                "window_reflected_temperature": windowReflectedTemperature.value,
                "window_reflection": windowReflection.value
            }
        else:
            return {
                "scene_emissivity": sceneEmissivity.value,
                "background_temperature": backgroundTemperature.value,
                "window_transmission": windowTransmission.value,
                "window_temperature": windowTemperature.value,
                "atmospheric_transmission": atmosphericTransmission.value,
                "atmospheric_temperature": atmosphericTemperature.value,
                "window_reflection": windowReflection.value,
                "window_reflected_temperature": windowReflectedTemperature.value
            }
        
    ### <summary>
    ### Sets the flux parameters for the camera's measurement system.
    ### </summary>
    ### <param name="sceneEmissivity">The emissivity of the scene.
    ### Range : 0.01 ~ 1.00
    ### </param>
    ### <param name="atmosphericTransmission">The atmospheric transmission factor.
    ### Range : 0.01 ~ 1.00</param>    
    ### <param name="atmosphericTemperature">The temperature of the atmosphere.
    ### Range(TMC80,TMC160) : -273.15 ~ 382.2 
    ### Range(TMC256) : -43.15 ~ 626.85</param>    
    ### <param name="windowReflectedTemperature">The temperature of the reflected window.
    ### Range(TMC80,TMC160) : -273.15 ~ 382.2 
    ### Range(TMC256) : -43.15 ~ 626.85</param>    
    ### <param name="windowReflection">The reflection factor of the window.
    ### For TMC256, this value means 'distance'.
	### Range : 0.00 ~ 0.00
    ### </param>    
    ### <param name="backgroundTemperature">Optional background temperature.
    ### Range : -273.15 ~ 382.2
	### For TMC256, initialize this value to NaN.
    ### </param>    
    ### <param name="windowTransmission">Optional window transmission factor.
    ### Range : 0.01 ~ 1.00
	### For TMC256, initialize this value to NaN.
    ### </param>    
    ### <param name="windowTemperature">Optional window temperature.
    ### Range : -273.15 ~ 382.2
	### For TMC256, initialize this value to NaN.
    ### </param>    
    ### <returns>
    ### A boolean value indicating success (True) or failure (False) of the operation.
    ### </returns>
    def set_flux_parameters(self, sceneEmissivity, atmosphericTransmission, atmosphericTemperature, 
                            windowReflectedTemperature, windowReflection, backgroundTemperature = math.nan,
                           windowTransmission = math.nan, windowTemperature = math.nan):
        if not self.obj:
            print("TmCamera object is not initialized!")
            return None

        func = libTmCore.TmCtrl_SetFluxParameters
        func.argtypes = [c_void_p, POINTER(c_bool), c_double, c_double, c_double
                         , c_double, c_double, c_double, c_double, c_double]
        func.restype = c_char_p
        ret = c_bool(False)
        result = func(self.obj, byref(ret), c_double(sceneEmissivity), c_double(atmosphericTransmission),
                c_double(atmosphericTemperature), c_double(windowReflectedTemperature), c_double(windowReflection),
                c_double(backgroundTemperature), c_double(windowTransmission), c_double(windowTemperature))
        if result:
            print('Error:', result.decode(sys.getdefaultencoding()))
            raise TmException(result.decode(sys.getdefaultencoding()))

        return ret.value
    
    ### <summary>
    ### Restores the default sensor configuration for the camera.
    ### </summary>
    ### <returns>
    ### A boolean value indicating success (True) or failure (False) of the operation.
    ### </returns>
    def restore_default_sensor_config(self):
        func = libTmCore.TmCtrl_RestoreDefaultSensorConfig
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        result = func(self.obj,byref(ret))
        if result:
            error_message=result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    
    ### <summary>
    ### Stores the current sensor configuration as the user-defined configuration.
    ### </summary>
    ### <returns>
    ### A boolean value indicating success (True) or failure (False) of the operation.
    ### </returns>
    def store_user_sensor_config(self):
        func = libTmCore.TmCtrl_StoreUserSensorConfig
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        result = func(self.obj,byref(ret))
        if result:
            error_message=result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    
    ### <summary>
    ### Sets the default flux parameters for the sensor.
    ### </summary>
    ### <returns>
    ### A tuple containing:
    ### - A boolean value indicating success (True) or failure (False) of the operation.
    ### - A dictionary with the following default flux parameters:
    ###   - `scene_emissivity`: The emissivity of the scene (default: 1).
    ###   - `background_temperature`: The background temperature (default: 22).
    ###   - `window_transmission`: The transmission through the window (default: 1).
    ###   - `window_temperature`: The temperature of the window (default: 22).
    ###   - `atmospheric_transmission`: The atmospheric transmission (default: 1).
    ###   - `atmospheric_temperature`: The atmospheric temperature (default: 22).
    ###   - `window_reflection`: The window reflection (default: 0).
    ###   - `window_reflected_temperature`: The temperature of the reflected window (default: 22).
    ### 
    ### </returns>
    def set_flux_default_parameters(self):
         sceneEmissivity = c_double(1)
         backgroundTemperature = c_double(22)
         windowTransmission = c_double(1)
         windowTemperature = c_double(22)
         atmosphericTransmission = c_double(1)
         atmosphericTemperature = c_double(22) 
         windowReflection = c_double(0)
         windowReflectedTemperature = c_double(22)
         func = libTmCore.TmCtrl_SetDefaultFluxParameters
         func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_double), POINTER(c_double), POINTER(c_double),
             POINTER(c_double), POINTER(c_double), POINTER(c_double), POINTER(c_double), POINTER(c_double)]
         func.restype = c_char_p
         ret = c_bool(False)
         try:
             result = func(
                 self.obj, pointer(ret), pointer(sceneEmissivity), pointer(atmosphericTransmission)
                 , pointer(atmosphericTemperature), pointer(windowReflectedTemperature), pointer(windowReflection)
                 , pointer(backgroundTemperature), pointer(windowTransmission), pointer(windowTemperature)
                 )
         except Exception as e:
             print(f"Error calling TmCtrl_SetDefaultFluxParameters8: {e}")
             return False
         if result:
             error_message = result.decode(sys.getdefaultencoding())
             raise TmException(error_message)

         return ret.value, {
         "scene_emissivity": sceneEmissivity.value,
         "background_temperature": backgroundTemperature.value,
         "window_transmission": windowTransmission.value,
         "window_temperature": windowTemperature.value,
         "atmospheric_transmission": atmosphericTransmission.value,
         "atmospheric_temperature": atmosphericTemperature.value,
         "window_reflection": windowReflection.value,
         "window_reflected_temperature": windowReflectedTemperature.value
         }
    
    ### <summary>
    ### Sets the flat field correction parameters for the sensor.
    ### </summary>
    ### <param name="maxInterval">The maximum interval for flat field correction.</param>
    ### <param name="autoTriggerThreshold">The automatic trigger threshold for flat field correction.</param>
    ### <returns>
    ### A boolean value indicating success (True) or failure (False) of the operation.
    ### 
    ### </returns>
    def set_flat_feild_correction_parameters(self, maxInterval, autoTriggerThreshold):
        func = libTmCore.TmCtrl_SetFlatFieldCorrectionParameters
        func.argtypes = [c_void_p, POINTER(c_bool), c_double, c_double]
        func.restype = c_char_p
        ret = c_bool(False)
        result = func(self.obj, byref(ret), c_double(maxInterval), c_double(autoTriggerThreshold))
        if result:
            error_message = result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    
    ### <summary>
    ### Sets the flat field correction mode on the sensor.
    ### </summary>
    ### <param name="arg">An integer representing the desired flat field correction mode. The possible values and their meanings should be defined in the documentation of the `TmCtrl_SetFlatFieldCorrectionMode` function.</param>
    ### <returns>
    ### A boolean indicating the success of the operation (True if successful, False otherwise).
    ### 
    ### </returns>
    def set_flat_feild_correction_mode(self,arg):
        func = libTmCore.TmCtrl_SetFlatFieldCorrectionMode
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        result = func(self.obj, byref(ret), c_int(arg))
        if result:
            error_message = result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    
    ### <summary>
    ### Initiates the flat field correction process on the sensor.
    ### </summary>
    ### <returns>
    ### A boolean indicating the success of the operation (True if successful, False otherwise).
    ### 
    ### </returns>
    def run_flat_field_correction(self):
        func = libTmCore.TmCtrl_RunFlatFieldCorrection
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        result = func(self.obj,byref(ret))
        if result:
            error_message=result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    
    ### <summary>
    ### Retrieves the product model name of the sensor.
    ### </summary>
    ### <returns>
    ### A string containing the product model name if successful; otherwise, `None`.
    ### 
    ### </returns>
    def get_product_model_name(self):
        func = libTmCore.TmCtrl_GetProductModelName
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        arg = (c_char * 255)()
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret.value == False:
            return None
        return arg.value.decode(sys.getdefaultencoding())
    
    ### <summary>
    ### Retrieves the product serial number of the sensor.
    ### </summary>
    ### <returns>
    ### A string containing the product serial number if successful; otherwise, `None`.
    ### 
    ### </returns>
    def get_product_serial(self):
        func = libTmCore.TmCtrl_GetProductSerialNumber
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char*255)]
        func.restype = c_char_p
        arg = (c_char*255)()
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret.value == False: 
            return None
        return arg.value.decode(sys.getdefaultencoding())
    
    ### <summary>
    ### Retrieves the hardware version of the camera.
    ### </summary>
    ### <returns>
    ### A string containing the hardware version if successful; otherwise, `None`.
    ### 
    ### </returns>
    def get_hardware_version(self):
        func = libTmCore.TmCtrl_GetHardwareVersion
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        arg=(c_char * 255)()
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret.value == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    
    ### <summary>
    ### Retrieves the bootloader version of the sensor.
    ### </summary>
    ### <returns>
    ### A string containing the bootloader version if successful; otherwise, `None`.
    ### 
    ### </returns>
    def get_bootloader_version(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_GetBootloaderVersion
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    
    ### <summary>
    ### Retrieves the firmware version of the sensor.
    ### </summary>
    ### <returns>
    ### A string containing the firmware version if successful; otherwise, `None`.
    ### 
    ### </returns>
    def get_firmware_version(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_GetFirmwareVersion
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    
    ### <summary>
    ### Retrieves the model name of the sensor.
    ### </summary>
    ### <returns>
    ### A string containing the sensor model name if successful; otherwise, `None`.
    ### 
    ### </returns>
    def get_sensor_model_name(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_GetSensorModelName
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    
    ### <summary>
    ### Retrieves the serial number of the sensor.
    ### </summary>
    ### <returns>
    ### A string containing the sensor serial number if successful; otherwise, `None`.
    ### 
    ### </returns>
    def get_sensor_serial_number(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_GetSensorSerialNumber
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    
    ### <summary>
    ### Retrieves the uptime of the sensor.
    ### </summary>
    ### <returns>
    ### A string containing the sensor uptime if successful; otherwise, `None`.
    ### 
    ### </returns>
    def get_sensor_uptime(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_GetSensorUptime
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    
    ### <summary>
    ### Restores the default sensor configuration.
    ### </summary>
    ### <returns>
    ### `True` if the default sensor configuration is successfully restored; otherwise, `False`.
    ### 
    ### </returns>
    def restore_default_sensor_config(self):
        func = libTmCore.TmCtrl_RestoreDefaultSensorConfig
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        result = func(self.obj, byref(ret))
        if result:
            error_message = result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    
    ### <summary>
    ### Retrieves the network configuration settings from the camera.
    ### </summary>
    ### <returns>
    ### A tuple containing:
    ### - A boolean value indicating the success or failure of the network configuration retrieval.
    ### - A dictionary with the following keys:
    ###     - `mac`: The MAC address of the camera.
    ###     - `ip_assign`: The IP assignment method (e.g., DHCP or Static).
    ###     - `ip`: The IP address of the camera.
    ###     - `netmask`: The subnet mask of the network.
    ###     - `gateway`: The gateway address.
    ###     - `dns`: The primary DNS server address.
    ###     - `dns2`: The secondary DNS server address.
    ### If the function fails to retrieve the network configuration, it prints an error message and returns `None`.
    ### </returns>
    def get_network_configuration(self):
        func = libTmCore.TmCtrl_GetNetworkConfiguration
        func.argtypes = [c_void_p, POINTER(c_bool), c_char_p, c_char_p,
            c_char_p, c_char_p, c_char_p, c_char_p, c_char_p
        ]
        func.restype = c_char_p
        ret = c_bool(False)
        mac = create_string_buffer(18)
        ip_assign = create_string_buffer(10)
        ip = create_string_buffer(16)
        netmask = create_string_buffer(16)
        gateway = create_string_buffer(16)
        dns = create_string_buffer(16)
        dns2 = create_string_buffer(16)
    
        try:
            result = func(self.obj, byref(ret), mac, ip_assign, ip, netmask, gateway, dns, dns2)
            if result:
                error_message = cast(result, c_char_p).value.decode(sys.getdefaultencoding())
                raise TmException(error_message)
            if not ret.value:
                return None
            return ret.value, {
                "mac": mac.value.decode(sys.getdefaultencoding()),
                "ip_assign": ip_assign.value.decode(sys.getdefaultencoding()),
                "ip": ip.value.decode(sys.getdefaultencoding()),
                "netmask": netmask.value.decode(sys.getdefaultencoding()),
                "gateway": gateway.value.decode(sys.getdefaultencoding()),
                "dns": dns.value.decode(sys.getdefaultencoding()),
                "dns2": dns2.value.decode(sys.getdefaultencoding())
            }
        except Exception as e:
            return None

    ### <summary>
    ### Sets the network configuration for the device.
    ### </summary>
    ### <param name="ip_assign" type="str">
    ### The IP assignment method (e.g., "DHCP" or "Static").
    ### </param>
    ### <param name="ip" type="str">
    ### The IP address to be set.
    ### </param>
    ### <param name="netmask" type="str">
    ### The network mask to be used.
    ### </param>
    ### <param name="gateway" type="str">
    ### The gateway IP address.
    ### </param>
    ### <param name="dns" type="str">
    ### The primary DNS server address.
    ### </param>
    ### <param name="dns2" type="str">
    ### The secondary DNS server address (can be an empty string if not used).
    ### </param>
    ### <returns>
    ### `True` if the network configuration is successfully set; otherwise, `False`.
    ### 
    ### </returns>
    def set_network_configuration(self, ip_assign, ip, netmask, gateway, dns, dns2):
        func = libTmCore.TmCtrl_SetNetworkConfiguration
        func.argtypes = [c_void_p, POINTER(c_bool), c_char_p, c_char_p
                         , c_char_p, c_char_p, c_char_p, c_char_p]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, byref(ret), ip_assign.encode('utf-8')
                                          , ip.encode('utf-8'), netmask.encode('utf-8')
                                          , gateway.encode('utf-8'), dns.encode('utf-8'), dns2.encode('utf-8')))
        return ret.value
    
    ### <summary>
    ### Retrieves the default network configuration from the device.
    ### </summary>
    ### <param name="None">
    ### This method does not take any parameters.
    ### </param>
    ### <returns>
    ### A tuple containing:
    ### - A boolean value indicating the success or failure of the network configuration retrieval.
    ### - A dictionary with the following keys:
    ###   - `ip_assign`: The IP assignment method (e.g., "DHCP" or "Static").
    ###   - `ip`: The IP address.
    ###   - `netmask`: The network mask.
    ###   - `gateway`: The gateway IP address.
    ###   - `dns`: The primary DNS server address.
    ###   - `dns2`: The secondary DNS server address (or an empty string if not used).
    ### 
    ### If the function call fails, an exception is raised, and `None` is returned.
    ### </returns>
    def set_default_network_configuration(self):
        func = libTmCore.TmCtrl_SetDefaultNetworkConfiguration
        func.argtypes = [c_void_p, POINTER(c_bool), c_char_p, c_char_p, c_char_p, c_char_p, c_char_p, c_char_p]
        func.restype = c_char_p
        ret = c_bool(False)
        ip_assign = create_string_buffer(10)
        ip = create_string_buffer(16)
        netmask = create_string_buffer(16)
        gateway = create_string_buffer(16)
        dns = create_string_buffer(16)
        dns2 = create_string_buffer(16)
    
        try:
            result = func(self.obj, byref(ret), ip_assign, ip, netmask, gateway, dns, dns2)
            if result:
                error_message = cast(result, c_char_p).value.decode(sys.getdefaultencoding())
                raise TmException(error_message)
            if not ret.value:
                return None
            return ret.value, {
                "ip_assign": ip_assign.value.decode(sys.getdefaultencoding()),
                "ip": ip.value.decode(sys.getdefaultencoding()),
                "netmask": netmask.value.decode(sys.getdefaultencoding()),
                "gateway": gateway.value.decode(sys.getdefaultencoding()),
                "dns": dns.value.decode(sys.getdefaultencoding()),
                "dns2": dns2.value.decode(sys.getdefaultencoding())
            }
        except Exception as e:
            print(f"An error occurred in get_network_configuration: {str(e)}")
            return None

    ### <summary>
    ### Reboots the device.
    ### </summary>
    ### <param name="None">
    ### This method does not take any parameters.
    ### </param>
    ### <returns>
    ### A boolean value indicating the success or failure of the reboot operation:
    ### - `True` if the device is successfully rebooted.
    ### - `False` if the reboot operation fails.
    ### 
    ### </returns>
    def reboot_device(self):
        func = libTmCore.TmCtrl_RebootDevice
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, byref(ret)))
        return ret.value
    
    ### <summary>
    ### check the firmware file is available for updating to current camera.
    ### </summary>
    ### <param name="file_path">
    ### The path to the firmware file that will be checked.
    ### </param>
    ### <returns>
    ### A tuple containing the following information if the check is successful:
    ### - A boolean indicating the result of the check (`True` if the firmware is compatible, `False` otherwise).
    ### - The vendor name of the firmware.
    ### - The product name associated with the firmware.
    ### - The version of the firmware.
    ### - The build time of the firmware.
    ### - The size of the firmware file.
    ### 
    ### </returns>
    def check_firmware(self, file_path):
        func = libTmCore.TmCtrl_CheckFirmware
        func.argtypes = [c_void_p, POINTER(c_bool), c_char_p, POINTER(c_char * 255),
            POINTER(c_char * 255), POINTER(c_char * 255), POINTER(c_char * 255), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        vendor = (c_char * 255)()
        product = (c_char * 255)()
        version = (c_char * 255)()
        build_time = (c_char * 255)()
        file_size  = c_int(0)
        TmException.ExceptionHandler(func(self.obj, byref(ret), file_path.encode('utf-8'), vendor, product, version, build_time, file_size))
        if ret.value == False:
            return
        return ret.value, vendor.value.decode(sys.getdefaultencoding()), product.value.decode(sys.getdefaultencoding()), version.value.decode(sys.getdefaultencoding()), build_time.value.decode(sys.getdefaultencoding()), file_size.value
        
    ### <summary>
    ### Opens and checks a firmware file, returning its size if valid.
    ### </summary>
    ### <param name="file_path">
    ### The path to the firmware file to be opened.
    ### </param>
    ### <returns>
    ### The size of the firmware file if the operation is successful. Returns `-1` if the file cannot be opened or if there is an error.
    ### 
    ### </returns>
    def open_firmware(self, file_path):
        func = libTmCore.TmCtrl_OpenFirmware
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int), c_char_p]
        func.restype = c_char_p
        ret = c_bool(False)
        size = c_int(0)
        TmException.ExceptionHandler(func(self.obj, byref(ret), byref(size), file_path.encode('utf-8')))
        if ret.value == False:
            return 0;
        return size.value

    ### <summary>
    ### Initiates the firmware update process and returns the progress percentage.
    ### </summary>
    ### <returns>
    ### The percentage of the firmware update progress if successful. Returns `-1` if the update fails or if there is an error.
    ### </returns>
    def update_firmware(self):
        func = libTmCore.TmCtrl_UpdateFirmware
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        percent = c_int(0)
        TmException.ExceptionHandler(func(self.obj, byref(ret), byref(percent)))
        if ret.value == False:
            return -1
        return percent.value
    
    ### <summary>
    ### Complete the firmware update.
    ### </summary>
    ### <returns>
    ### `True` if the firmware file was successfully closed. Returns `False` if there was an error or if closing the firmware failed.
    ### </returns>
    def close_firmware(self):
        func = libTmCore.TmCtrl_CloseFirmware
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, byref(ret)))
        return ret.value
    
