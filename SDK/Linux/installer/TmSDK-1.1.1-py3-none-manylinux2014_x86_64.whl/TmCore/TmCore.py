###  @mainpage TmSDK
###  @section  Introduction
###    This is the Python API documents for TmSDK.
###  @section  Modules
###  - TmCore       : The fundamental features
###  @section  TmCore
###  - TmCamera
###  - TmControl
###  - TmFrame
###  - TmRoi
###  - TmException
###  @section  CREATEINFO  Creator
###  - Author : Thermoeye, Inc
###  - Date   : 2024/07/22
###  @section  HISTORY  Revision History
###  - Initial Release     : 2024/07/22    - 1.0.0
###  - Support multiple remote cameras.    : 2025/01/17    - 1.1.0
###  - Fixed the bugs in the TmCtrl256::SetGainModeState and TmCtrl256::GetGainModeState APIs.     : 2025/02/11    - 1.1.1
