import os, sys
from ctypes import *
from .TmException import *
from .TmTypes import *
from . import libTmCore

### <summary>
### RoiObject
### </summary>
class RoiObject(object):
    ### <summary>
    ### Creates a new instance of the <c>RoiObject</c> class.
    ### </summary>
    ### <param name="ptr"></param>
    def __init__(self, roi_type = None):
        func = libTmCore.TmRoiObject_Ctor
        func.argtypes = ()
        func.restype = c_void_p
        self.obj = func()
        self.type = roi_type
        
    ### <summary>
    ### Get the type of the Region of Interest (ROI) from the ROI object.
    ### </summary>
    ### <returns>
    ### The type of the ROI as an enumerated value of type `RoiType`. 
    ### If the operation fails, the method returns the default invalid ROI type value (`-1`).
    ### RoiType.Hand = 0, Spot = 1, Line = 2, Rect = 3, Ellipse = 4    
    ### </returns>
    def get_roi_type(self):
        func = libTmCore.TmRoiObject_GetRoiType
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(RoiType)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = RoiType(-1)
        ret = TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return arg.value
    
    ### <summary>
    ### Retrieves the minimum value and the coordinates of the region of interest (ROI) in the ROI object.
    ### </summary>
    ### <returns>
    ### A `LocItem` object containing the minimum location details of the ROI. 
    ### </returns>
    def get_roi_minloc(self):
        func = libTmCore.TmRoiObject_GetMinLoc
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(LocItem)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = LocItem()
        ret = TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return arg
    
    ### <summary>
    ### Retrieves the average value of the region of interest (ROI) in the ROI object.
    ### </summary>
    ### <returns>
    ### A `LocItem` object containing the minimum location details of the ROI. 
    ### </returns>
    def get_roi_avgloc(self):
        func = libTmCore.TmRoiObject_GetAvgLoc
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(LocItem)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = LocItem()
        ret = TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return arg
    
    ### <summary>
    ### Retrieves the maximum value and the coordinates of the region of interest (ROI) in the ROI object.
    ### </summary>
    ### <returns>
    ### A `LocItem` object containing the minimum location details of the ROI. 
    ### </returns>
    def get_roi_maxloc(self):
        func = libTmCore.TmRoiObject_GetMaxLoc
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(LocItem)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = LocItem()
        ret = TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return arg
        
class RoiSpot(RoiObject):
    ### <summary>
    ### Initializes a `RoiSpot` object. Depending on the arguments, different constructors are used:
    ### </summary>
    ### <param name="args">
    ### - `0` arguments: Calls the default constructor for a `Spot` ROI.
    ### - `1` argument of type `int`: Calls the constructor that initializes a `Spot` ROI with the specified index.
    ### - `1` argument of type `Point`: Calls the constructor that initializes a `Spot` ROI with the specified point.
    ### - `2` arguments of type `int`: Calls the constructor that initializes a `Spot` ROI with the specified x and y coordinates.
    ### - `3` arguments where the first is `int` and the remaining two are `int`: Calls the constructor that initializes a `Spot` ROI with the specified index, x, and y coordinates.
    ### - `1` argument of type `RoiObject`: Initializes the `RoiSpot` object using the `obj` attribute of the provided `RoiObject`.
    ### </param>
    def __init__(self, *args):
        super().__init__(RoiType.Spot)
        
        if len(args) == 0:
            func = libTmCore.TmRoiSpot_Ctor
            func.argtypes = ()
            func.restype = c_void_p
            self.obj = func()
        elif len(args) == 1 and isinstance(args[0], int):
            index = args[0]
            func = libTmCore.TmRoiSpot_Ctor_Index
            func.argtypes = [c_int]
            func.restype = c_void_p
            self.obj = func(index)
        elif len(args) == 1 and isinstance(args[0], Point):
            pt = args[0]
            func = libTmCore.TmRoiSpot_Ctor_Point
            func.argtypes = [Point]
            func.restype = c_void_p
            self.obj = func(pt)
        elif len(args) == 2 and all(isinstance(arg, int) for arg in args):
            x, y = args
            func = libTmCore.TmRoiSpot_Ctor_XY
            func.argtypes = [c_int, c_int]
            func.restype = c_void_p
            self.obj = func(x, y)
        elif len(args) == 3 and isinstance(args[0], int) and all(isinstance(arg, int) for arg in args[1:]):
            index, x, y = args
            func = libTmCore.TmRoiSpot_Ctor_IndexXY
            func.argtypes = [c_int, c_int, c_int]
            func.restype = c_void_p
            self.obj = func(index, x, y)
        elif len(args) == 1 and isinstance(args[0], RoiObject):
            roiObject = args[0]
            self.obj = roiObject.obj
        else:
            raise ValueError("Invalid arguments for RoiRect constructor")     
    
    ### <summary>
    ### Get the spot location of the ROI.
    ### </summary>
    ### <returns>
    ### A `Point` object representing the location of the spot in the ROI.
    ### </returns>
    def get_roi_spot(self):
        func = libTmCore.TmRoiSpot_GetSpot
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(Point)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = Point()
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return arg
        
class RoiLine(RoiObject):
    ### <summary>
    ### Initializes a `RoiLine` object. Depending on the arguments, different constructors are used:
    ### </summary>
    ### <param name="args">
    ### - `0` arguments: Calls the default constructor for a `Line` ROI.
    ### - `1` argument of type `int`: Calls the constructor that initializes a `Line` ROI with the specified index.
    ### - `1` argument of type `Point`: Calls the constructor that initializes a `Line` ROI with the specified starting point.
    ### - `2` arguments of type `int`: Calls the constructor that initializes a `Line` ROI with the specified starting x and y coordinates.
    ### - `3` arguments where the first is `int` and the remaining two are `int`: Calls the constructor that initializes a `Line` ROI with the specified index, starting x, and y coordinates.
    ### - `1` argument of type `RoiObject`: Initializes the `RoiLine` object using the `obj` attribute of the provided `RoiObject`.
    ### </param>
    def __init__(self, *args):
        super().__init__(RoiType.Line)
        
        if len(args) == 0:
            func = libTmCore.TmRoiLine_Ctor
            func.argtypes = ()
            func.restype = c_void_p
            self.obj = func()
        elif len(args) == 1 and isinstance(args[0], int):
            index = args[0]
            func = libTmCore.TmRoiLine_Ctor_Index
            func.argtypes = [c_int]
            func.restype = c_void_p
            self.obj = func(index)
        elif len(args) == 1 and isinstance(args[0], Point):
            pt = args[0]
            func = libTmCore.TmRoiLine_Ctor_Point
            func.argtypes = [Point]
            func.restype = c_void_p
            self.obj = func(pt)
        elif len(args) == 2 and all(isinstance(arg, int) for arg in args):
            x, y = args
            func = libTmCore.TmRoiLine_Ctor_XY
            func.argtypes = [c_int, c_int]
            func.restype = c_void_p
            self.obj = func(x, y)
        elif len(args) == 3 and isinstance(args[0], int) and all(isinstance(arg, int) for arg in args[1:]):
            index, x, y = args
            func = libTmCore.TmRoiLine_Ctor_IndexXY
            func.argtypes = [c_int, c_int, c_int]
            func.restype = c_void_p
            self.obj = func(index, x, y)
        elif len(args) == 1 and isinstance(args[0], RoiObject):
            roiObject = args[0]
            self.obj = roiObject.obj
        else:
            raise ValueError("Invalid arguments for RoiRect constructor")     
        
    ### <summary>
    ### Get the start and end points of the line ROI.
    ### </summary>
    ### <returns>
    ### A tuple of two `Point` objects representing the start and end points of the line ROI.
    ### </returns>
    def get_roi_line(self):
        func = libTmCore.TmRoiLine_GetLine
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(Point), POINTER(Point)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg1 = Point()
        arg2 = Point()
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg1), pointer(arg2)))
        return arg1, arg2

class RoiRect(RoiObject):
    ### <summary>
    ### Initializes a `RoiRect` object. The constructor supports various forms of initialization:
    ### </summary>
    ### <param name="args">
    ### - `0` arguments: Calls the default constructor for a rectangle ROI.
    ### - `1` argument of type `int`: Calls the constructor that initializes a rectangle ROI with the specified index.
    ### - `1` argument of type `Point`: Calls the constructor that initializes a rectangle ROI with the specified top-left corner point.
    ### - `2` arguments of type `int`: Calls the constructor that initializes a rectangle ROI with the specified top-left corner coordinates (x, y) and width (w) and height (h).
    ### - `3` arguments where the first is `int` and the rest are `int`: Calls the constructor that initializes a rectangle ROI with the specified index, top-left corner coordinates (x, y), and dimensions (w, h).
    ### - `1` argument of type `RoiObject`: Initializes the `RoiRect` object using the `obj` attribute of the provided `RoiObject`.
    ### </param>
    def __init__(self, *args):
        super().__init__(RoiType.Rect)
        
        if len(args) == 0:
            func = libTmCore.TmRoiRect_Ctor
            func.argtypes = ()
            func.restype = c_void_p
            self.obj = func()
        elif len(args) == 1 and isinstance(args[0], int):
            index = args[0]
            func = libTmCore.TmRoiRect_Ctor_Index
            func.argtypes = [c_int]
            func.restype = c_void_p
            self.obj = func(index)
        elif len(args) == 1 and isinstance(args[0], Point):
            pt = args[0]
            func = libTmCore.TmRoiRect_Ctor_Point
            func.argtypes = [Point]
            func.restype = c_void_p
            self.obj = func(pt)
        elif len(args) == 2 and all(isinstance(arg, int) for arg in args):
            x, y, w, h = args
            func = libTmCore.TmRoiRect_Ctor_XYWH
            func.argtypes = [c_int, c_int, c_int, c_int]
            func.restype = c_void_p
            self.obj = func(x, y, w, h)
        elif len(args) == 3 and isinstance(args[0], int) and all(isinstance(arg, int) for arg in args[1:]):
            index, x, y, w, h = args
            func = libTmCore.TmRoiRect_Ctor_IndexXYWH
            func.argtypes = [c_int, c_int, c_int, c_int, c_int]
            func.restype = c_void_p
            self.obj = func(index, x, y, w, h)
        elif len(args) == 1 and isinstance(args[0], RoiObject):
            roiObject = args[0]
            self.obj = roiObject.obj
        else:
            raise ValueError("Invalid arguments for RoiRect constructor")
    
    ### <summary>
    ### Get the rectangle's top-left corner and its width and height.
    ### </summary>
    ### <returns>
    ### A `Rectangle` object representing the top-left corner and dimensions (width and height) of the rectangle ROI.
    ### </returns>
    def get_roi_rect(self):
        func = libTmCore.TmRoiRect_GetRectangle
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(Rectangle)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = Rectangle()
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return arg
    
class RoiEllipse(RoiObject):
    ### <summary>
    ### Initializes a `RoiEllipse` object. The constructor supports various forms of initialization:
    ### </summary>
    ### <param name="args">
    ### - `0` arguments: Calls the default constructor for an ellipse ROI.
    ### - `1` argument of type `int`: Calls the constructor that initializes an ellipse ROI with the specified index.
    ### - `1` argument of type `Point`: Calls the constructor that initializes an ellipse ROI with the specified center point.
    ### - `4` arguments of type `int`: Calls the constructor that initializes an ellipse ROI with the specified center coordinates (x, y) and width (w) and height (h).
    ### - `5` arguments where the first is `int` and the rest are `int`: Calls the constructor that initializes an ellipse ROI with the specified index, center coordinates (x, y), and dimensions (w, h).
    ### - `1` argument of type `RoiObject`: Initializes the `RoiEllipse` object using the `obj` attribute of the provided `RoiObject`.
    ### </param>
    def __init__(self, *args):
        super().__init__(RoiType.Ellipse)
        
        if len(args) == 0:
            func = libTmCore.TmRoiEllipse_Ctor
            func.argtypes = ()
            func.restype = c_void_p
            self.obj = func()
        elif len(args) == 1 and isinstance(args[0], int):
            index = args[0]
            func = libTmCore.TmRoiEllipse_Ctor_Index
            func.argtypes = [c_int]
            func.restype = c_void_p
            self.obj = func(index)
        elif len(args) == 1 and isinstance(args[0], Point):
            pt = args[0]
            func = libTmCore.TmRoiEllipse_Ctor_Point
            func.argtypes = [Point]
            func.restype = c_void_p
            self.obj = func(pt)
        elif len(args) == 2 and all(isinstance(arg, int) for arg in args):
            x, y, w, h = args
            func = libTmCore.TmRoiEllipse_Ctor_XYWH
            func.argtypes = [c_int, c_int, c_int, c_int]
            func.restype = c_void_p
            self.obj = func(x, y, w, h)
        elif len(args) == 3 and isinstance(args[0], int) and all(isinstance(arg, int) for arg in args[1:]):
            index, x, y, w, h = args
            func = libTmCore.TmRoiEllipse_Ctor_IndexXYWH
            func.argtypes = [c_int, c_int, c_int, c_int, c_int]
            func.restype = c_void_p
            self.obj = func(index, x, y, w, h)
        elif len(args) == 1 and isinstance(args[0], RoiObject):
            roiObject = args[0]
            self.obj = roiObject.obj
        else:
            raise ValueError("Invalid arguments for RoiRect constructor")
        
    ### <summary>
    ### Get the ellipse's bounding box as a `Rectangle`.
    ### </summary>
    ### <returns>
    ### A `Rectangle` object representing the bounding box of the ellipse ROI, including its position and dimensions (width and height).
    ### </returns>
    def get_roi_ellipse(self):
        func = libTmCore.TmRoiEllipse_GetEllipse
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(Rectangle)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = Rectangle()
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return arg
    
### <summary>
### TmRoiManager
### </summary>
class TmRoiManager(object):
    ### <summary>
    ### Creates a new instance of the <c>TmRoiManager</c> class.
    ### </summary>
    def __init__(self):
        func = libTmCore.TmRoi_Ctor
        func.argtypes = ()
        func.restype = c_void_p
        self.obj = func()
        # self.items = []
        
    ### <summary>
    ### Destroys an instance of the <c>TmRoiManager</c> class, releasing any resources associated with it.
    ### </summary>
    def __del__(self):
        func = libTmCore.TmRoi_Dtor
        func.argtypes = [c_void_p]
        func.restype = None
        func(self.obj)
        
    ### <summary>
    ### Get the type of the currently selected ROI.
    ### </summary>
    ### <returns>
    ### An integer representing the type of the selected ROI.
    ### </returns>
    def get_selected_roi_type(self):
        func = libTmCore.TmRoi_GetSelectedRoiType
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return arg.value
    
    ### <summary>
    ### Set the type of the currently selected ROI.
    ### </summary>
    ### <param name="arg">
    ### An instance of the `RoiType` enum representing the desired ROI type to be set.
    ### </param>
    ### <returns>
    ### A boolean indicating the success of the operation. 
    ### </returns>
    def set_selected_roi_type(self, arg):
        func = libTmCore.TmRoi_SetSelectedRoiType
        func.argtypes = [c_void_p, POINTER(c_bool), RoiType]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    
    ### <summary>
    ### Get the currently selected ROI item.
    ### </summary>
    ### <returns>
    ### An instance of `RoiObject` representing the currently selected ROI item. 
    ### </returns>
    def selected_item(self):
        func = libTmCore.TmRoi_SelectedItem
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_void_p
        ret = c_bool(False)
        arg = RoiObject()
        arg.obj = func(self.obj, pointer(ret))
        return arg

    ### <summary>
    ### Clear all ROIs associated with the current object.
    ### </summary>
    ### <returns>
    ### A boolean value indicating the success of the operation.
    ### </returns>
    def roi_clear(self):
        func = libTmCore.TmRoi_Clear
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    
    ### <summary>
    ### Act a mouse down event at the given point.
    ### </summary>
    ### <param name="pt">
    ### A `Point` object representing the coordinates where the mouse down event should be simulated.
    ### </param>
    ### <returns>
    ### A boolean value indicating the success of the operation.
    ### </returns>
    def mouse_down(self, pt):
        func = libTmCore.TmRoi_MouseDown
        func.argtypes = [c_void_p, POINTER(c_bool), Point]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pt))
        return ret.value
    
    ### <summary>
    ### Act a mouse up event at the given point.
    ### </summary>
    ### <param name="pt">
    ### A `Point` object representing the coordinates where the mouse up event should be simulated.
    ### </param>
    ### <returns>
    ### A boolean value indicating the success of the operation.
    ### </returns>
    def mouse_up(self, pt):
        func = libTmCore.TmRoi_MouseUp
        func.argtypes = [c_void_p, POINTER(c_bool), Point]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pt))
        return ret.value
    
    ### <summary>
    ### Act a mouse move event at the given point.
    ### </summary>
    ### <param name="pt">
    ### A `Point` object representing the coordinates where the mouse up event should be simulated.
    ### </param>
    ### <returns>
    ### A boolean value indicating the success of the operation.
    ### </returns>
    def mouse_move(self, pt):
        func = libTmCore.TmRoi_MouseMove
        func.argtypes = [c_void_p, POINTER(c_bool), Point]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pt))
        return ret.value

    ### <summary>
    ### Add a new ROI item at the specified coordinates.
    ### </summary>
    ### <param name="type">
    ### An enumeration of type `RoiType` representing the type of ROI item to be added.
    ### </param>
    ### <param name="x">
    ### An integer representing the x-coordinate where the ROI item should be placed.
    ### </param>
    ### <param name="y">
    ### An integer representing the y-coordinate where the ROI item should be placed.
    ### </param>
    ### <returns>
    ### A boolean value indicating the success of the operation.
    ### </returns>
    def add_item_xy(self, type, x, y):
        func = libTmCore.TmRoi_AddItem_XY
        func.argtypes = [c_void_p, POINTER(c_bool), RoiType, c_int, c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), type, x, y))
        return ret.value
    
    ### <summary>
    ### Add a new ROI item with the specified coordinates and dimensions.
    ### </summary>
    ### <param name="type">
    ### An enumeration of type `RoiType` representing the type of ROI item to be added.
    ### </param>
    ### <param name="x">
    ### An integer representing the x-coordinate of the top-left corner of the ROI item.
    ### </param>
    ### <param name="y">
    ### An integer representing the y-coordinate of the top-left corner of the ROI item.
    ### </param>
    ### <param name="w">
    ### An integer representing the width of the ROI item.
    ### </param>
    ### <param name="h">
    ### An integer representing the height of the ROI item.
    ### </param>
    ### <returns>
    ### A boolean value indicating the success of the operation.
    ### </returns>
    def add_item_xywh(self, type, x, y, w, h):
        func = libTmCore.TmRoi_AddItem_XYWH
        func.argtypes = [c_void_p, POINTER(c_bool), RoiType, c_int, c_int, c_int, c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), type, x, y, w, h))
        return ret.value
    
    ### <summary>
    ### Remove an ROI item from the collection based on its index.
    ### </summary>
    ### <param name="index">
    ### An integer representing the index of the ROI item to be removed.
    ### </param>
    ### <returns>
    ### A boolean value indicating the success of the operation.
    ### </returns>
    def remove_at(self, index):
        func = libTmCore.TmRoi_RemoveAt
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), index))
        return ret.value

    ### <summary>
    ### Get an ROI item from the collection based on its index.
    ### </summary>
    ### <param name="index">
    ### An integer representing the index of the ROI item to be retrieved.
    ### </param>
    ### <returns>
    ### An instance of `RoiObject` representing the ROI item at the specified index.
    ### </returns>
    def get_roi_item(self, index):
        func = libTmCore.TmRoi_GetItem
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_void_p
        ret = c_bool(False)
        item = RoiObject()
        item.obj = func(self.obj, pointer(ret), index)
        return item
    
    ### <summary>
    ### Get an ROI spot item from the collection based on its index.
    ### </summary>
    ### <param name="index">
    ### An integer representing the index of the ROI spot item to be retrieved.
    ### </param>
    ### <returns>
    ### An instance of `RoiSpot` representing the ROI spot item at the specified index.
    ### </returns>
    def get_roi_spot_item(self, index):
        func = libTmCore.TmRoi_GetItem
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_void_p
        ret = c_bool(False)
        item = RoiSpot()
        item.obj = func(self.obj, pointer(ret), index)
        return item
    
    ### <summary>
    ### Get an ROI line item from the collection based on its index.
    ### </summary>
    ### <param name="index">
    ### An integer representing the index of the ROI line item to be retrieved.
    ### </param>
    ### <returns>
    ### An instance of `RoiLine` representing the ROI line item at the specified index.
    ### </returns>
    def get_roi_line_item(self, index):
        func = libTmCore.TmRoi_GetItem
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_void_p
        ret = c_bool(False)
        item = RoiLine()
        item.obj = func(self.obj, pointer(ret), index)
        return item

    ### <summary>
    ### Get an ROI rectangle item from the collection based on its index.
    ### </summary>
    ### <param name="index">
    ### An integer representing the index of the ROI rectangle item to be retrieved.
    ### </param>
    ### <returns>
    ### An instance of `RoiRect` representing the ROI rectangle item at the specified index.
    ### </returns>
    def get_roi_rect_item(self, index):
        func = libTmCore.TmRoi_GetItem
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_void_p
        ret = c_bool(False)
        item = RoiRect()
        item.obj = func(self.obj, pointer(ret), index)
        return item
    
    ### <summary>
    ### Get an ROI ellipse item from the collection based on its index.
    ### </summary>
    ### <param name="index">
    ### An integer representing the index of the ROI ellipse item to be retrieved.
    ### </param>
    ### <returns>
    ### An instance of `RoiEllipse` representing the ROI ellipse item at the specified index.
    ### </returns>
    def get_roi_ellipse_item(self, index):
        func = libTmCore.TmRoi_GetItem
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_void_p
        ret = c_bool(False)
        item = RoiEllipse()
        item.obj = func(self.obj, pointer(ret), index)
        return item
    
    ### <summary>
    ### Get the total count of ROI items.
    ### </summary>
    ### <param name="None">
    ### This method does not require any parameters.
    ### </param>
    ### <returns>
    ### An integer representing the number of ROI items in the collection.
    ### </returns>
    def get_roi_item_count(self):
        func = libTmCore.TmRoi_GetItemCount
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        count = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(count)))
        return count.value
    
    ### <summary>
    ### Get the type of the ROI item at the specified index.
    ### </summary>
    ### <param name="index">
    ### An integer representing the index of the ROI item for which the type is to be retrieved.
    ### </param>
    ### <returns>
    ### An enumeration value of type `RoiType` representing the type of the ROI item at the given index.
    ### </returns>
    def get_roi_type(self, index):
        func = libTmCore.TmRoi_GetRoiType
        func.argtypes = [c_void_p, POINTER(c_bool), c_int, POINTER(RoiType)]
        func.restype = c_char_p
        ret = c_bool(False)
        type = RoiType()
        TmException.ExceptionHandler(func(self.obj, pointer(ret), index, pointer(type)))
        return type.value
    