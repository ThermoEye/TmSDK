import os, sys
from .config import *
from ctypes import *
TMCOREDIR = os.path.dirname(__file__)

libTmCore = CDLL
if sys.platform.startswith("linux"):  # could be "linux", "linux2", "linux3", ...
    TMCOREDIR = '/usr/lib/TmSDK/'
    dll_path = os.path.join(TMCOREDIR, f"libTmCore.{config.TMSDK_VERSION}.so")
    sys.path.append(TMCOREDIR)
    libTmCore = cdll.LoadLibrary(dll_path)
elif os.name == "nt":
    TMCOREDIR = os.environ.get('TMSDK_BIN')
    os.environ['PATH'] = ';'.join([os.environ['PATH'], TMCOREDIR])
    dll_path = os.path.join(TMCOREDIR, f"libTmCore.{config.TMSDK_VERSION}.dll")
    libTmCore = cdll.LoadLibrary(dll_path)

from .TmException import *
from .TmTypes import *
from .TmCamera import *
from .TmFrame import *
from .TmControl import *
from .TmRoi import *

__all__ = ['TmException', 'TmCamera', 'TmFrame', 'TmTypes', 'TmControl', 'TmRoiManager']

