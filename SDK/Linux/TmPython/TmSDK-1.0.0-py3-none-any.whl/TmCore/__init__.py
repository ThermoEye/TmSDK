import os, sys
#sys.path.append(os.path.dirname(__file__))
#sys.path.append(os.path.join(os.path.dirname(__file__), "lib"))
from ctypes import *
VERSION = 1.0
TMCOREDIR = os.path.dirname(__file__)

libTmCore = CDLL
if sys.platform.startswith("linux"):  # could be "linux", "linux2", "linux3", ...
   dll_path = os.path.join(TMCOREDIR, "libTmCore.so")
   sys.path.append(TMCOREDIR)
   libTmCore = cdll.LoadLibrary(dll_path)
elif os.name == "nt":
   os.environ['PATH'] = ';'.join([os.environ['PATH'], TMCOREDIR])
   dll_path = os.path.join(TMCOREDIR, "libTmCore.dll")
   print(f"TMCOREDIR : {TMCOREDIR}")
   print(f"DLL PATH : {dll_path}")
   libTmCore = cdll.LoadLibrary(dll_path)

from .TmException import *
from .TmTypes import *
from .TmCamera import *
from .TmFrame import *
from .TmControl import *
from .TmRoi import *

__all__ = ['TmException', 'TmCamera', 'TmFrame', 'TmTypes', 'TmControl', 'TmRoiManager']

print(f"TmCore : {VERSION}")