import os, sys
from ctypes import *

from .TmException import *
from .TmTypes import *

from . import libTmCore

### <summary>
### TmFrame
### </summary>
class TmFrame(object):
    ### <summary>
    ### Ctor
    ### </summary>
    ### <param name="ptr"></param>
    def __init__(self):
        # func = libTmCore.TmFrame_Ctor
        # func.argtypes = ()
        # func.restype = c_void_p
        # self.obj = func()
        self.obj = c_void_p()
        
      
    ### <summary>
    ### Dispose of TmFrame
    ### </summary>
    def __del__(self):
        func = libTmCore.TmFrame_Dtor
        func.argtypes = [c_void_p]
        func.restype = None
        func(self.obj)
      
    def to_bitmap(self, colorOrder):
        func = libTmCore.TmFrame_ToBitMap
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = POINTER(c_ubyte)
        width = self.width()
        height = self.height()
        ret = c_bool(False)
        pData = func(self.obj, pointer(ret), colorOrder)
        return bytes(pData[:width * height * 3])
    
    ### <summary>
    ### Width of TmFrame
    ### </summary>
    def width(self):
        func = libTmCore.TmFrame_Width
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_void_p
        ret = c_bool(False)
        val = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(val)))
        if ret is False:
            return None      
        return val.value   
    ### <summary>
    ### Height of TmFrame
    ### </summary>
    def height(self):
        func = libTmCore.TmFrame_Height
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_void_p

        ret = c_bool(False)
        val = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(val)))
        if ret is False:
            return None      
        return val.value

    ### <summary>
    ### Get minimum and maximum value with locations in TmFrame
    ### </summary>
    ### <param name="rect"></param>
    ### <param name="minVal"></param>
    ### <param name="maxVal"></param>
    ### <param name="minLoc"></param>
    ### <param name="maxLoc"></param>
    ### <returns></returns>
    def min_max_loc(self):
        func = libTmCore.TmFrame_MinMaxLoc
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_double), POINTER(c_double), POINTER(c_double), POINTER(Point), POINTER(Point)]
        func.restype = c_void_p

        ret = c_bool(False)
        minVal = c_double(-1.0)
        avgVal = c_double(-1.0)
        maxVal = c_double(-1.0)
        minLoc = Point()
        maxLoc = Point()
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(minVal), pointer(avgVal), pointer(maxVal), pointer(minLoc), pointer(maxLoc)))
        if ret is False:
            return None
        return minVal.value, avgVal.value, maxVal.value, minLoc, maxLoc
    ### <summary>
    ### Measure all roi items in TmFrame
    ### </summary>
    ### <returns></returns>
    def do_measure(self, arg):
        func = libTmCore.TmFrame_DoMeasure
        func.argtypes = [c_void_p, POINTER(c_bool), c_void_p]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg.obj))
        if ret is False:
            return None
        return ret.value
        