from calendar import c
import ctypes
import os, sys
import re
from ctypes import *
# from typing_extensions import Buffer

#from . import QRCOREDIR
from .TmException import *
from . import libTmCore

class TmControl(object):
    def __init__(self):
        self.obj = c_void_p()

    ##### TmControl ###########################################################
    ### <summary>
    ### Set protocol type
    ### </summary>
    ### <param name="arg">CtrlProtocol</param>
    ### <returns></returns>
    def PutProtocol(self, arg):
        func = libTmCore.TmCtrl_PutProtocol
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    def SetProtocol(self, arg):
        func = libTmCore.TmCtrl_SetProtocol
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value


    ### <summary>
    ### Get product model name
    ### </summary>
    ### <returns></returns>
    def GetProductModelName(self, arg):
        func = libTmCore.TmCtrl_GetProductModelName
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char_p)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return ret.value
    

    ### <summary>
    ### Get hardware version information
    ### </summary>
    ### <returns></returns>
    def GetHardwareVersion(self):
        func = libTmCore.TmCtrl_GetHardwareVersion
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get software version information
    ### </summary>
    ### <returns></returns>
    def GetSoftwareVersion(self):
        func = libTmCore.TmCtrl_GetSoftwareVersion
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get reference gain value
    ### </summary>
    ### <returns></returns>
    def GetRefGain(self):
        func = libTmCore.TmCtrl_GetRefGain
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get reference offset value
    ### </summary>
    ### <returns></returns>
    def GetRefOffset(self):
        func = libTmCore.TmCtrl_GetRefOffset
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get temperature coefficient 1 value
    ### </summary>
    ### <returns></returns>
    def GetTempCoeff1(self):
        func = libTmCore.TmCtrl_GetTempCoeff1
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get temperature coefficient 2 value
    ### </summary>
    ### <returns></returns>
    def GetTempCoeff2(self):
        func = libTmCore.TmCtrl_GetTempCoeff2
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get FPA temperature
    ### </summary>
    ### <returns></returns>
    def GetTempFPA(self):
        func = libTmCore.TmCtrl_GetTempFPA
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get body temperature
    ### </summary>
    ### <returns></returns>
    def GetTempBody(self):
        func = libTmCore.TmCtrl_GetTempBody
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get hot mode which is HotBlack or HotWhite
    ### </summary>
    ### <returns></returns>
    def GetHotMode(self):
        func = libTmCore.TmCtrl_GetHotMode
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Set hot mode
    ### </summary>
    ### <param name="arg">HotMode : HotWhite or HotBlack</param>
    ### <returns></returns>
    def SetHotMode(self, arg):
        func = libTmCore.TmCtrl_SetHotMode
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Get system settings which are usecase and display setting
    ### </summary>
    ### <returns></returns>
    def GetSystemSetting(self):
        func = libTmCore.TmCtrl_GetSystemSetting
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get product model information
    ### </summary>
    ### <returns></returns>
    def GetModel(self):
        func = libTmCore.TmCtrl_GetModel
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get product information
    ### </summary>
    ### <returns></returns>
    def GetProductInfo(self):
        func = libTmCore.TmCtrl_GetProductInfo
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get system information
    ### </summary>
    ### <returns></returns>
    def GetSystemInfo(self):
        func = libTmCore.TmCtrl_GetSystemInfo
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get camera sensor serial information
    ### </summary>
    ### <returns></returns>
    def GetSensorSerial(self):
        func = libTmCore.TmCtrl_GetSensorSerialNumber
        func.argtypes = [c_void_p, POINTER(c_bool),c_char_p]
        func.restype = c_char_p
        ret = c_bool(False)        
        buffer=ctypes.create_string_buffer(1024)
        TmException.ExceptionHandler(func(self.obj, pointer(ret),buffer))
        print('ret:',ret)
        return buffer.value.decode('utf-8')
        
    ### <summary>
    ### Get product serial information
    ### </summary>
    ### <returns></returns>
    def GetProductSerial(self):
        func=libTmCore.TmCtrl_GetProductSerialNumber
        func.argtypes=[c_void_p,POINTER(c_bool),POINTER(c_char*255)]
        func.restype=c_char_p
        arg=(c_char*255)()
        ret=c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret.value == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    ### <summary>
    ### Get version information 
    ### </summary>
    ### <returns></returns>
    def GetVersionInfo(self):
        func = libTmCore.TmCtrl_GetVersionInfo
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get statistics information
    ### </summary>
    ### <returns></returns>
    def GetStatistics(self):
        func = libTmCore.TmCtrl_GetStatistics
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get current gain mode
    ### </summary>
    ### <returns></returns>
    def GetGainMode(self):
        func = libTmCore.TmCtrl_GetGainMode
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Set gain mode
    ### </summary>
    ### <param name="arg">Gain : high or low</param>
    ### <returns></returns>
    def SetGainMode(self, arg):
        func = libTmCore.TmCtrl_SetGainMode
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Get current auto shutter mode
    ### </summary>
    ### <returns></returns>
    def GetAutoShutter(self):
        func = libTmCore.TmCtrl_GetAutoShutter
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value  
    ### <summary>
    ### Set auto shutter mode
    ### </summary>
    ### <param name="arg">on or off</param>
    ### <returns></returns>
    def SetAutoShutter(self, arg):
        func = libTmCore.TmCtrl_SetAutoShutter
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Set auto shutter time 
    ### </summary>
    ### <param name="arg">as milleseconds</param>
    ### <returns></returns>
    def SetAutoShutterTime(self, arg):
        func = libTmCore.TmCtrl_SetAutoShutterTime
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value    
    ### <summary>
    ### Set NUC alarm
    ### </summary>
    ### <param name="arg">on or off</param>
    ### <returns></returns>
    def SetAlarmNUC(self, arg):
        func = libTmCore.TmCtrl_SetAlarmNUC
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Do 1-point reference NUC
    ### </summary>
    ### <returns></returns>
    def Set1pNUC(self):
        func = libTmCore.TmCtrl_Set1pNUC
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Set temperature converter feature
    ### </summary>
    ### <param name="arg">on or off</param>
    ### <returns></returns>
    def SetTempConvert(self, arg):
        func = libTmCore.TmCtrl_SetTempConvert
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Set reference gain value
    ### </summary>
    ### <param name="arg"></param>
    ### <returns></returns>
    def SetRefGain(self, arg):
        func = libTmCore.TmCtrl_SetRefGain
        func.argtypes = [c_void_p, POINTER(c_bool), c_float]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Set reference offset value
    ### </summary>
    ### <param name="arg"></param>
    ### <returns></returns>
    def SetRefOffset(self, arg):
        func = libTmCore.TmCtrl_SetRefOffset
        func.argtypes = [c_void_p, POINTER(c_bool), c_float]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Set temperature coefficient 1 value
    ### </summary>
    ### <param name="arg"></param>
    ### <returns></returns>
    def SetTempCoeff1(self, arg):
        func = libTmCore.TmCtrl_SetTempCoeff1
        func.argtypes = [c_void_p, POINTER(c_bool), c_float]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Set temperature coefficient 2 value
    ### </summary>
    ### <param name="arg"></param>
    ### <returns></returns>
    def SetTempCoeff2(self, arg):
        func = libTmCore.TmCtrl_SetTempCoeff2
        func.argtypes = [c_void_p, POINTER(c_bool), c_float]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Set TRSM compensation feature
    ### </summary>
    ### <param name="arg">on or off</param>
    ### <returns></returns>
    def SetTrsmComp(self, arg):
        func = libTmCore.TmCtrl_SetTrsmComp
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value         
    def SetTrsmRefValue(self, arg):
        func = libTmCore.TmCtrl_SetTrsmRefValue
        func.argtypes = [c_void_p, POINTER(c_bool), c_float]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Set TRSM guide feature
    ### </summary>
    ### <param name="arg">on or off</param>
    ### <returns></returns>
    def SetTrsmGuide(self, arg):
        func = libTmCore.TmCtrl_SetTrsmGuide
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Save current TRSM guide setting
    ### </summary>
    ### <returns></returns>
    def SetTrsmGuideSave(self):
        func = libTmCore.TmCtrl_SetTrsmGuideSave
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Set TRSM guide directon
    ### </summary>
    ### <param name="arg">left, right, up or down</param>
    ### <returns></returns>
    def SetTrsmGuideTo(self, arg):
        func = libTmCore.TmCtrl_SetTrsmGuideTo
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value       
    ### <summary>
    ### Get temperature fpa and body value
    ### </summary>
    ### <returns></returns>
    def GetTempInfo(self):
        func = libTmCore.TmCtrl_GetTempInfo
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Set temperature printable
    ### </summary>
    ### <param name="arg">on or off</param>
    ### <returns></returns>
    def SetTempPrint(self, arg):
        func = libTmCore.TmCtrl_SetTempPrint
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Assert reboot to network
    ### </summary>
    ### <returns></returns>
    def SetNetworkReboot(self):
        func = libTmCore.TmCtrl_SetNetworkReboot
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get current Ip mode which is static or dhcp setting only for a remote camera
    ### </summary>
    ### <returns></returns>
    def GetIpMode(self):
        func = libTmCore.TmCtrl_GetIpMode
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Set IP mode only to a remote camera
    ### </summary>
    ### <param name="arg">static or DHCP</param>
    ### <returns></returns>
    def SetIpMode(self, arg):
        func = libTmCore.TmCtrl_SetIpMode
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Get current IP address only for a remote camera
    ### </summary>
    ### <returns></returns>
    def GetIpAddress(self):
        func = libTmCore.TmCtrl_GetIpAddress
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Set IP address only to a remote camera
    ### </summary>
    ### <param name="arg"></param>
    ### <returns></returns>
    def SetIpAddress(self, arg0, arg1, arg2 ,arg3):
        func = libTmCore.TmCtrl_SetIpAddress
        func.argtypes = [c_void_p, POINTER(c_bool), c_ubyte, c_ubyte, c_ubyte, c_ubyte]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg0, arg1, arg2 ,arg3))
        return ret.value
    ### <summary>
    ### Get current MAC address only for a remote camera
    ### </summary>
    ### <returns></returns>
    def GetMacAddress(self):
        func = libTmCore.TmCtrl_GetMacAddress
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get current gateway address only for a remote camera
    ### </summary>
    ### <returns></returns>
    def GetGatewayAddress(self):
        func = libTmCore.TmCtrl_GetGatewayAddress
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Set gateway address only to a remote camera
    ### </summary>
    ### <param name="arg"></param>
    ### <returns></returns>
    def SetGatewayAddress(self, arg0, arg1, arg2 ,arg3):
        func = libTmCore.TmCtrl_SetGatewayAddress
        func.argtypes = [c_void_p, POINTER(c_bool), c_ubyte, c_ubyte, c_ubyte, c_ubyte]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg0, arg1, arg2 ,arg3))
        return ret.value
    ### <summary>
    ### Get current subnet mask only for a remote camera
    ### </summary>
    ### <returns></returns>
    def GetSubnetMask(self):
        func = libTmCore.TmCtrl_GetSubnetMask
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Set subnet mask only to a remote camera
    ### </summary>
    ### <param name="arg"></param>
    ### <returns></returns>
    def SetSubnetMask(self, arg0, arg1, arg2 ,arg3):
        func = libTmCore.TmCtrl_SetSubnetMask
        func.argtypes = [c_void_p, POINTER(c_bool), c_ubyte, c_ubyte, c_ubyte, c_ubyte]
        func.restype = c_char_p
        ret = c_bool(False)
        print(f'btnSetSubnetMask_Clicked : {arg0}.{arg1}.{arg2}.{arg3}')
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg0, arg1, arg2 ,arg3))
        return ret.value       
    ### <summary>
    ### Get current DNS address only for a remote camera
    ### </summary>
    ### <returns></returns>
    def GetDnsAddress(self):
        func = libTmCore.TmCtrl_GetDnsAddress
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Set DNS address only to a remote camera
    ### </summary>
    ### <param name="arg"></param>
    ### <returns></returns>
    def SetDnsAddress(self, arg0, arg1, arg2 ,arg3):
        func = libTmCore.TmCtrl_SetDnsAddress
        func.argtypes = [c_void_p, POINTER(c_bool), c_ubyte, c_ubyte, c_ubyte, c_ubyte]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg0, arg1, arg2 ,arg3))
        return ret.value
    ### <summary>
    ### Get current video resolution only for a remote camera
    ### </summary>
    ### <returns></returns>
    def GetVideoResolution(self):
        func = libTmCore.TmCtrl_GetVideoResolution
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get current video fps only for a remote camera
    ### </summary>
    ### <returns></returns>
    def GetVideoFPS(self):
        func = libTmCore.TmCtrl_GetVideoFPS
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Get current video format only for a remote camera
    ### </summary>
    ### <returns></returns>
    def GetVideoFormat(self):
        func = libTmCore.TmCtrl_GetVideoFormat
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value      


    ###########################################################################
    #   PROPERTIES
    ###########################################################################    
    ### <summary>
    ### Product model
    ### </summary>
    def Model(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_Model
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    ### <summary>
    ### Product version
    ### </summary>
    def ProductVersion(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_ProductVersion
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    ### <summary>
    ### Hardware version
    ### </summary>
    def HardwareVersion(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_GetHardwareVersion
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    ### <summary>
    ### Software version
    ### </summary>
    def SoftwareVersion(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_SoftwareVersion
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    ### <summary>
    ### Firmware build date
    ### </summary>
    def BuildDate(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_BuildDate
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    ### <summary>
    ### Firmware build time
    ### </summary>
    def BuildTime(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_BuildTime
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    ### <summary>
    ### Product serial number
    ### </summary>
    def ProductSerial(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_ProductSerial
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    ### <summary>
    ### Camera sensor serial number
    ### </summary>
    def SensorSerial(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_GetSensorSerialNumber
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        print('open ret =',ret.value)
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    ### <summary>
    ### Reference gain value
    ### </summary>
    def RefGain(self):
        arg = c_float(-1)
        func = libTmCore.TmCtrl_RefGain
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_float)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Reference offset value
    ### </summary>
    def RefOffset(self):
        arg = c_float(-1)
        func = libTmCore.TmCtrl_RefOffset
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_float)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Temperature coefficient 1 value
    ### </summary>
    def EstTempCoeff1(self):
        arg = c_float(-1)
        func = libTmCore.TmCtrl_EstTempCoeff1
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_float)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Temperature coefficient 2 value
    ### </summary>
    def EstTempCoeff2(self):
        arg = c_float(-1)
        func = libTmCore.TmCtrl_EstTempCoeff2
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_float)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Current UseCase
    ### </summary>
    def UseCase(self):
        func = libTmCore.TmCtrl_UseCase
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = (c_char * 255)()
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding()) 
    ### <summary>
    ### Current display setting
    ### </summary>
    def DisplaySetting(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_DisplaySetting
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())    
    ### <summary>
    ### Current capture setting
    ### </summary>
    def CaptureSetting(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_CaptureSetting
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())   
    ### <summary>
    ### Current boot mode
    ### </summary>
    def get_boot_loader_version(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_GetBootLoaderVersion
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())   
    ### <summary>
    ### Current auto shutter mode
    ### </summary>
    def AutoShutterMode(self):
        arg = c_bool(False)
        func = libTmCore.TmCtrl_AutoShutterMode
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Current auto shutter mode
    ### </summary>
    def AutoShutter(self):
        func = libTmCore.TmCtrl_AutoShutter
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Current brightness level
    ### </summary>
    def BrightnessLevel(self):
        arg = c_int(-1)
        func = libTmCore.TmCtrl_BrightnessLevel
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value 
    ### <summary>
    ### Current contrast level
    ### </summary>
    def ContrastLevel(self):
        arg = c_int(-1)
        func = libTmCore.TmCtrl_ContrastLevel
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Current hot mode
    ### </summary>
    def HotMode(self):
        func = libTmCore.TmCtrl_HotMode
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Current hot mode as string
    ### </summary>
    def HotModeStr(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_HotModeStr
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding()) 
    ### <summary>
    ### Current pseudo color
    ### </summary>
    def PseudoColor(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_PseudoColor
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())    
    ### <summary>
    ### Current video output format
    ### </summary>
    def OutputFormat(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_OutputFormat
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())  
    ### <summary>
    ### Currnet CEM
    ### </summary>
    def CEM(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_CEM
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding()) 
    ### <summary>
    ### Current gain mode
    ### </summary>
    def GainMode(self):
        arg = c_int(-1)
        func = libTmCore.TmCtrl_GainMode
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Current FPA temperature value
    ### </summary>
    def TempFPA(self):
        arg = c_float(-1)
        func = libTmCore.TmCtrl_TempFPA
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_float)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Current body temperature value
    ### </summary>
    def TempBody(self):
        arg = c_float(-1)
        func = libTmCore.TmCtrl_TempBody
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_float)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Current IP mode only from a remote camera
    ### </summary>
    def IpMode(self):
        arg = c_ubyte(0)
        func = libTmCore.TmCtrl_IpMode
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_ubyte)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return bytes(arg)
    ### <summary>
    ### Current IP address only from a remote camera
    ### </summary>
    def IpAddress(self):
        arg = (c_ubyte * 4)()
        func = libTmCore.TmCtrl_IpAddress
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_ubyte * 4)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return bytes(arg)
    ### <summary>
    ### Current MAC address only from a remote camera
    ### </summary>
    def MacAddress(self):
        arg = (c_ubyte * 6)()
        func = libTmCore.TmCtrl_MacAddress
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_ubyte * 6)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return bytes(arg)
    ### <summary>
    ### Current gateway address only from a remote camera
    ### </summary>
    def GatewayAddress(self):
        arg = (c_ubyte * 4)()
        func = libTmCore.TmCtrl_GatewayAddress
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_ubyte * 4)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return bytes(arg)
    ### <summary>
    ### Current subnet mask only from a remote camera
    ### </summary>
    def SubnetMask(self):
        arg = (c_ubyte * 4)()
        func = libTmCore.TmCtrl_SubnetMask
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_ubyte * 4)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return bytes(arg)
    ### <summary>
    ### Current DNS address only from a remote camera
    ### </summary>
    def DnsAddress(self):
        arg = (c_ubyte * 4)()
        func = libTmCore.TmCtrl_DnsAddress
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_ubyte * 4)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return bytes(arg)
    ### <summary>
    ### Current width of video frame
    ### </summary>
    def VideoWidth(self):
        arg = c_int(-1)
        func = libTmCore.TmCtrl_VideoWidth
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Current height of video frame
    ### </summary>
    def VideoHeight(self):
        arg = c_int(-1)
        func = libTmCore.TmCtrl_VideoHeight
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Current fps of video stream
    ### </summary>
    def VideoFPS(self):
        arg = c_int(-1)
        func = libTmCore.TmCtrl_VideoFPS
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        if ret == False: return None
        return arg.value
    ### <summary>
    ### Current video format of video stream
    ### </summary>
    def VideoFormat(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_VideoFormat
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    ### <summary>
    ### Get statistics information
    ### </summary>
    def Statistics(self):
        func = libTmCore.TmCtrl_StatisticsCount
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))

        count = arg.value
        print(f"count = {count}")

        func = libTmCore.TmCtrl_Statistics
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 1024 * count)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = (c_char * 1024 * count)()
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        statistics = [ item.value.decode(sys.getdefaultencoding()) for item in arg ]
        return statistics
    ### <summary>
    ### Set shutter control
    ### </summary>
    ### <param name="arg">open or close</param>
    ### <returns></returns>
    def SetShutterControl(self, arg):
        func = libTmCore.TmCtrl_SetShutterControl
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Reboot system
    ### </summary>
    ### <returns></returns>
    def SetSystemReboot(self):
        func = libTmCore.TmCtrl_SetSystemReboot
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    ### <summary>
    ### Set View Mode
    ### </summary>
    ### <returns></returns>
    def SetViewMode(self, arg):
        func = libTmCore.TmCtrl_SetViewMode
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Set TEC
    ### </summary>
    ### <returns></returns>
    def SetTEC(self, arg):
        func = libTmCore.TmCtrl_SetTEC
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Set Dead Pixel Compensation
    ### </summary>
    ### <returns></returns>
    def SetDPC(self, arg):
        func = libTmCore.TmCtrl_SetDPC
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Set 2nd Compensation
    ### </summary>
    ### <returns></returns>
    def Set2ndComp(self, arg):
        func = libTmCore.TmCtrl_Set2ndComp
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        print(f'Set2ndComp = {arg}')
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Set Shutter Compensation
    ### </summary>
    ### <returns></returns>
    def SetShutterComp(self, arg):
        func = libTmCore.TmCtrl_SetShutterComp
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Set Image out
    ### </summary>
    ### <returns></returns>
    def SetImageOut(self, arg):
        func = libTmCore.TmCtrl_SetImageOut
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    ### <summary>
    ### Set TRSM reference temperature
    ### </summary>
    ### <param name="arg">on or off</param>
    ### <returns></returns>
    def SetTrsmRefTemp(self, arg):
        func = libTmCore.TmCtrl_SetTrsmRefTemp
        func.argtypes = [c_void_p, POINTER(c_bool), c_float]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    def ConvertRawToCelsius(self, raw):
        func = libTmCore.native_TmCtrl_ConvertRawToCelsius
        func.argtypes = [c_void_p, POINTER(c_bool), c_double]
        func.restype = c_char_p
        
        ret = c_bool(False)
        result = func(self.obj, pointer(ret), c_double(raw))
        
        TmException.ExceptionHandler(result)
        
        return ret.value
    
    def ConvertRawToFahrenheit(self, raw):
        func = libTmCore.native_TmCtrl_ConvertRawToFahrenheit
        func.argtypes = [c_void_p, POINTER(c_bool), c_double]
        func.restype = c_char_p
        
        ret = c_bool(False)
        result = func(self.obj, pointer(ret), c_double(raw))
        
        TmException.ExceptionHandler(result)
        
        return ret.value
    def ConvertRawToKelvin(self, raw):
        func = libTmCore.native_TmCtrl_ConvertRawToKelvin
        func.argtypes = [c_void_p, POINTER(c_bool), c_double]   
        func.restype = c_char_p
        
        ret = c_bool(False)
        result = func(self.obj, pointer(ret), c_double(raw))
        
        TmException.ExceptionHandler(result)
        
        return ret.value
