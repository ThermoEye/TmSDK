from audioop import lin2adpcm
import dis
from math import dist, e
import os, sys
from socket import gaierror
from pickle import NONE
from ctypes import *
from telnetlib import GA, TM
#from tkinter.tix import MAX
from token import AT
from types import NoneType

#from . import QRCOREDIR
from .TmException import *
from . import libTmCore

from .TmFrame import *
from .TmControl import *

### <summary>
### TmCamera
### </summary>
class TmCamera(object):
    ### <summary>
    ### Ctor of TmCamera
    ### </summary>
    def __init__(self):
        #self.obj = None
        self.obj = c_void_p()
        self.tmControl = None

    #def __del__(self):
    #    if self.obj is not None:
    #        func = libTmCore.TmCamera_Dtor
    #        func.argtypes = [c_void_p]
    #        func.restype = None
    #        func(self.obj)
    ### <summary>
    ### Enumeration of local cameras
    ### </summary>
    ### <returns></returns>
    @staticmethod
    def get_local_camera_list():
        # func = libTmCore.TmCamera_GetCameraNamesCount
        # func.argtypes = []
        # func.restype = c_int
        # count = func()
        count = 20

        # ret = (c_char * 255 * count)()
        # func = libTmCore.TmCamera_GetCameraNamesArray
        # func.argtypes = [POINTER(c_char * 255 * count)] # char[][255]
        # func.restype = None
        # func(pointer(ret))
        # rets = [ item.value.decode(sys.getdefaultencoding()) for item in ret ]

        max_string = 100
        name = (c_char * max_string * count)()
        port = (c_char * max_string * count)()
        index = (c_int * count)()
        func = libTmCore.TmCamera_GetLocalCameraListArray
        func.argtypes = [POINTER(c_char * max_string * count), POINTER(c_char * max_string * count), POINTER(c_int * count)]
        func.restype = None
        func(pointer(name), pointer(port), pointer(index))

        names = [ item.value.decode(sys.getdefaultencoding()) for item in name ]
        ports = [ item.value.decode(sys.getdefaultencoding()) for item in port ]
        indexes = [ item for item in index ]
        return names, ports, indexes, count
    
    @staticmethod
    def get_remote_camera_list(max_count = 50):
        max_string = 100
        name = (c_char * max_string * max_count)()
        serial = (c_char * max_string * max_count)()
        mac = (c_char * max_string * max_count)()
        ip = (c_char * max_string * max_count)()
        func = libTmCore.TmCamera_GetRemoteCameraListArray
        func.argTypes = [POINTER(c_char * max_string * max_count), \
                         POINTER(c_char * max_string * max_count), \
                         POINTER(c_char * max_string * max_count), \
                         POINTER(c_char * max_string * max_count)]
        func.restype = c_int
        count = func(pointer(name), pointer(serial), pointer(mac), pointer(ip))
        names = [ item.value.decode(sys.getdefaultencoding()) for item in name ]
        serials = [ item.value.decode(sys.getdefaultencoding()) for item in serial ]
        macs = [ item.value.decode(sys.getdefaultencoding()) for item in mac ]
        ips = [ item.value.decode(sys.getdefaultencoding()) for item in ip ]
        
        return names, serials, macs, ips, count
    ###########################################################################
    #   METHOS
    ###########################################################################
    ### <summary>
    ### Connect a remote TmCamera 
    ### </summary>
    ### <param name="camera">Index:Local Camera, IP address:Remote Camera</param>
    ### <returns></returns>
    def open_local_camera(self, name, comPort, index):
        func = libTmCore.TmCamera_CtorLocal
        func.argtypes = ()
        func.restype = c_void_p
        self.obj = func()
        if self.obj is None:
            return False
        func = libTmCore.TmCamera_LocalOpen
        func.argtypes = [c_void_p, POINTER(c_bool), c_char_p, c_char_p, c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), name.encode('utf-8'), comPort.encode('utf-8'), index))
        return ret.value
    
    def open_remote_camera(self, name, serialnumber, mac, ip):
        func = libTmCore.TmCamera_CtorRemote
        func.argtypes = ()
        func.restype = c_void_p
        self.obj = func()
        if self.obj is None:
            return False            

        func = libTmCore.TmCamera_RemoteOpen
        func.argtypes = [c_void_p, POINTER(c_bool), c_char_p, c_char_p, c_char_p, c_char_p]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), name.encode('utf-8'), serialnumber.encode('utf-8'), mac.encode('utf-8'), ip.encode('utf-8')))
        return ret.value
    
    # def query_frame(self, width, height):
    #     func = libTmCore.TmCamera_QueryFrame
    #     func.argtypes = [c_void_p, POINTER(c_bool), c_void_p, c_int, c_int]
    #     func.restype = c_void_p
    #     ret = c_bool(False)
    #     frame = TmFrame()
    #     TmException.ExceptionHandler(func(self.obj, pointer(ret), frame.obj, width, height))
    #     # frame.obj = func(self.obj, byref(ret), width, height)
    #     print(f'py query_frame = {frame.obj}')
    #     if frame.obj is None:
    #         frame = None
    #     return frame
    
    # def query_frame(self, width, height):
    #     func = libTmCore.TmCamera_QueryFrame
    #     func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_void_p), c_int, c_int]
    #     func.restype = c_char_p
    #     ret = c_bool(False)
    #     frame = TmFrame()
    #     TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(frame.obj), width, height))
    #     if ret.value == False:
    #         frame = None
    #     else:
    #         print(f'query_frame = ret = {ret.value}, frame = {frame}')
    #         print(f'query_frame = ret = {ret.value}, frame.obj = {frame.obj}')
    #     return frame
    
    def query_frame(self, width, height):
        func = libTmCore.TmCamera_QueryFrame
        func.argtypes = [c_void_p, POINTER(c_bool), c_int, c_int]
        func.restype = c_void_p
        ret = c_bool(False)
        frame = TmFrame()
        frame.obj = func(self.obj, pointer(ret), width, height)
        if ret.value == False:
            frame = None
            
        return frame
    
    
    ### <summary>
    ### Close the opened camera control interface
    ### </summary>
    ### <returns></returns>        
    def close(self):
        func = libTmCore.TmCamera_Close
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        if ret == True:
            self.TmControl = None
        return ret.value
    
    def get_temp_unit(self):
        func = libTmCore.TmCamera_GetTempUnit
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return arg
    
    def set_temp_unit(self, arg):
        func = libTmCore.TmCamera_SetTempUnit
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value

    def get_temperature(self, raw):
        # Define the function from the library
        func = libTmCore.TmCamera_GetTemperature
    
        # Set the argument types and return type
        func.argtypes = [c_void_p, POINTER(c_bool), c_double, POINTER(c_double)]
        func.restype = c_char_p
    
        # Prepare the arguments
        ret = c_bool(False)
        raw_value = c_double(raw)
        result = c_double(0.0)
        # Call the function and handle any exceptions
        TmException.ExceptionHandler(func(self.obj, pointer(ret), raw_value, pointer(result)))
        return result.value 
    
        
        
    def set_color_map(self, arg):
        func = libTmCore.TmCamera_SetColorMap
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    
    def set_noise_filtering(self, arg):
        func = libTmCore.TmCamera_SetNoiseFiltering
        func.argtypes = [c_void_p, POINTER(c_bool), c_bool]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    

    ### Camera Contols API
    def get_product_model_name(self):
        func = libTmCore.TmCtrl_GetProductModelName
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        arg = (c_char * 255)()
        ret = c_bool(False)
        print(f'get_product_model_name ....')
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret.value == False: return None
        return arg.value.decode(sys.getdefaultencoding())   
    def get_product_serial(self):
        func=libTmCore.TmCtrl_GetProductSerialNumber
        func.argtypes=[c_void_p,POINTER(c_bool),POINTER(c_char*255)]
        func.restype=c_char_p
        arg=(c_char*255)()
        ret=c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret.value == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    def get_product_serial(self):
        func=libTmCore.TmCtrl_GetProductSerialNumber
        func.argtypes=[c_void_p,POINTER(c_bool),POINTER(c_char*255)]
        func.restype=c_char_p
        arg=(c_char*255)()
        ret=c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret.value == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    def get_hardware_version(self):
        func = libTmCore.TmCtrl_GetHardwareVersion
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        arg=(c_char * 255)()
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret.value == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    def get_bootloader_version(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_GetBootloaderVersion
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding()) 
    def get_firmware_version(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_GetFirmwareVersion
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    def get_sensor_model_name(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_GetSensorModelName
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    def get_sensor_serial_number(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_GetSensorSerialNumber
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    def get_sensor_uptime(self):
        arg = (c_char * 255)()
        func = libTmCore.TmCtrl_GetSensorUptime
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_char * 255)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        if ret == False: return None
        return arg.value.decode(sys.getdefaultencoding())
    def get_flux_parameters5(self):
        if not self.obj:
         print("TmCamera object is not initialized!")
         return
        func = libTmCore.TmCtrl_GetFluxParameters5
        func.argtypes = [
            c_void_p,
            POINTER(c_bool),
            POINTER(c_double),
            POINTER(c_double),
            POINTER(c_double),
            POINTER(c_double),
            POINTER(c_double)]
        func.restype = c_char_p

        ret = c_bool(False)
        emissivity = c_double(0)
        atmospheric_transmittance = c_double(0)
        atmospheric_temperature= c_double(0)
        ambient_reflection_temperature= c_double(0)
        distance = c_double(0)
        print("Calling TmCtrl_GetFluxParameters8 with:")
        print("self.obj:", self.obj)
        print("Pointers:", pointer(ret), pointer(emissivity), pointer(atmospheric_transmittance), pointer(atmospheric_temperature),
          pointer(ambient_reflection_temperature), pointer(distance))
        result =func(
             self.obj,
             pointer(ret),
             pointer(emissivity),
             pointer(atmospheric_transmittance),
             pointer(atmospheric_temperature),
             pointer(ambient_reflection_temperature),
             pointer(distance)
         )

        if result:
           print('inside result:',result)
           error_message=result.decode(sys.getdefaultencoding())
           raise TmException(error_message)

        if not ret.value:
           print("TmCtrl_GetFluxParameters8 failed!")
           print('Result:',result)
           print("Return Value:",ret.value)
           return None

        return {
            "emissivity": emissivity.value,
            "atmospheric_transmittance": atmospheric_transmittance.value,
            "atmospheric_temperature": atmospheric_temperature.value,
            "ambient_reflection_temperature": ambient_reflection_temperature.value,
            "distance": distance.value
        }
    def get_flux_parameters8(self):
        if not self.obj:
         print("TmCamera object is not initialized!")
         return
        func = libTmCore.TmCtrl_GetFluxParameters8
        func.argtypes = [
            c_void_p,
            POINTER(c_bool),
            POINTER(c_double),
            POINTER(c_double),
            POINTER(c_double),
            POINTER(c_double),
            POINTER(c_double),
            POINTER(c_double),
            POINTER(c_double),
            POINTER(c_double)]
        func.restype = c_char_p

        ret = c_bool(False)
        scenEmissivity = c_double(0)
        backgroundTemperature = c_double(0)
        windowTransmission= c_double(0)
        windowTemperature= c_double(0)
        atmosphericTransmission= c_double(0)
        atmosphericTemperature= c_double(0)
        windowReflection= c_double(0)
        windowReflectedTemperature = c_double(0)
        print("Calling TmCtrl_GetFluxParameters8 with:")
        print("self.obj:", self.obj)
        print("Pointers:", pointer(ret), pointer(scenEmissivity), pointer(backgroundTemperature), pointer(windowTransmission),
          pointer(windowTemperature), pointer(atmosphericTransmission), 
          pointer(atmosphericTemperature),pointer(windowReflection), pointer(windowReflectedTemperature))
        result =func(
             self.obj,
             pointer(ret),
             pointer(scenEmissivity),
             pointer(backgroundTemperature),
             pointer(windowTransmission),
             pointer(windowTemperature),
             pointer(atmosphericTransmission),
             pointer(atmosphericTemperature),
             pointer(windowReflection),
             pointer(windowReflectedTemperature)
         )

        if result:
           print('inside result:',result)
           error_message=result.decode(sys.getdefaultencoding())
           raise TmException(error_message)

        if not ret.value:
           print("TmCtrl_GetFluxParameters8 failed!")
           print('Result:',result)
           print("Return Value:",ret.value)
           return None

        return {
            "scane_emissivity": scenEmissivity.value,
            "background_temperature": backgroundTemperature.value,
            "window_transmission": windowTransmission.value,
            "window_temperature": windowTemperature.value,
            "atmospheric_transmission": atmosphericTransmission.value,
            "atmospheric_temperature": atmosphericTemperature.value,
            "window_reflection": windowReflection.value,
            "window_reflected_temperature": windowReflectedTemperature.value
        }
    
    def set_flux_parameters8(self, sceneEmissivity, backgroundTemperature, windowTransmission, windowTemperature,
                             atmosphericTransmission, atmosphericTemperature, windowReflection, windowReflectedTemperature):
        if not self.obj:
            print("TmCamera object is not initialized!")
            return None

        func = libTmCore.TmCtrl_SetFluxParameters8
        func.argtypes = [
            c_void_p,
            POINTER(c_bool),
            c_double,
            c_double,
            c_double,
            c_double,
            c_double,
            c_double,
            c_double,
            c_double
        ]
        func.restype = c_char_p

        ret = c_bool(False)
    
        print("Calling TmCtrl_SetFluxParameters8 with:")
        print("self.obj:", self.obj)
        print("Parameters:", sceneEmissivity, backgroundTemperature, windowTransmission,
              windowTemperature, atmosphericTransmission, atmosphericTemperature,
              windowReflection, windowReflectedTemperature)

        result = func(
            self.obj,
            byref(ret),
            c_double(sceneEmissivity),
            c_double(backgroundTemperature),
            c_double(windowTransmission),
            c_double(windowTemperature),
            c_double(atmosphericTransmission),
            c_double(atmosphericTemperature),
            c_double(windowReflection),
            c_double(windowReflectedTemperature)
        )

        if result:
            print('Error:', result.decode(sys.getdefaultencoding()))
            raise TmException(result.decode(sys.getdefaultencoding()))

        return ret.value
    
    def set_flux_parameters5(self, emissivity, atmosphericTransmittance,atmosphericTemperature , ambientReflectionTemperature,distance):
                             
        if not self.obj:
            print("TmCamera object is not initialized!")
            return None

        func = libTmCore.TmCtrl_SetFluxParameters5
        func.argtypes = [
            c_void_p,
            POINTER(c_bool),
            c_double,
            c_double,
            c_double,
            c_double,
            c_double ]
        func.restype = c_char_p

        ret = c_bool(False)
    
        print("Calling TmCtrl_SetFluxParameters5 with:")
        print("self.obj:", self.obj)
        print("Parameters:", emissivity, atmosphericTransmittance, atmosphericTemperature , ambientReflectionTemperature,distance)
        
        result = func(
            self.obj,
            byref(ret),
            c_double(emissivity),
            c_double(atmosphericTransmittance),
            c_double(atmosphericTemperature),
            c_double(ambientReflectionTemperature),
            c_double(distance)
        )

        if result:
            error_message=result.decode(sys.getdefaultencoding())
            print('Error:', error_message)
            raise TmException(error_message)
            
        return ret.value
    def get_flat_feild_correction_parameters(self):
        if not self.obj:
            print('TmCamera object is not initialized!')
            return
        func=libTmCore.TmCtrl_GetFlatFieldCorrectionParameters
        func.argtypes=[c_void_p,POINTER(c_bool),POINTER(c_double),POINTER(c_double)]
        func.restype=c_char_p
        ret=c_bool(False)
        max_interval=c_double(0)
        auto_trigger_threshold=c_double(0)
        print("Calling TmCamera_GetFlatFeildCorrectionParameters with:")
        print("self.obj:",self.obj)
        print("Pointers:",pointer(ret),pointer(max_interval),pointer(auto_trigger_threshold))
        result=func(self.obj,byref(ret),pointer(max_interval),pointer(auto_trigger_threshold))
        if result:
            error_message=result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value,max_interval.value,auto_trigger_threshold.value
    def set_flat_feild_correction_parameters(self,maxInterval,autoTriggerThreshold):
        if not self.obj:
            print('TmCamera object is not initialized!')
            return
        func=libTmCore.TmCtrl_SetFlatFieldCorrectionParameters
        func.argtypes=[c_void_p,POINTER(c_bool),c_double,c_double]
        func.restype=c_char_p
        ret=c_bool(False)
        print("Calling TmCamera_SetFlatFeildCorrectionParameters with:")
        print("self.obj:",self.obj)
        print("Parameters:",maxInterval,autoTriggerThreshold)
        result=func(self.obj,byref(ret),c_double(maxInterval),c_double(autoTriggerThreshold))
        if result:
            error_message=result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    def get_gain_mode_state(self):
        if not self.obj:
            print('TmCamera object is not initialized!')
            return
        func=libTmCore.TmCtrl_GetGainModeState
        func.argtypes=[c_void_p,POINTER(c_bool),POINTER(c_int)]
        func.restype=c_char_p
        ret=c_bool(False)
        gain_mode=c_int(0)
        print("Calling TmCamera_GetGainModeState with:")
        print("self.obj:",self.obj)
        result=func(self.obj,byref(ret),pointer(gain_mode))
        if result:
            error_message=result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value,gain_mode.value
    def set_gain_mode_state(self,gain_mode):
        if not self.obj:
            print('TmCamera object is not initialized!')
            return
        func=libTmCore.TmCtrl_SetGainModeState
        func.argtypes=[c_void_p,POINTER(c_bool),c_int]
        func.restype=c_char_p
        ret=c_bool(False)
        print("Calling TmCamera_SetGainModeState with:")
        print("self.obj:",self.obj)
        print("Parameters:",gain_mode)
        result=func(self.obj,byref(ret),c_int(gain_mode))
        if result:
            error_message=result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    def get_flat_field_correction_mode(self):
        if not self.obj:
            print("TmCamera object is not initialized!")
            return None

        func = libTmCore.TmCtrl_GetFlatFieldCorrectionMode
        func.argtypes = [
            c_void_p,
            POINTER(c_bool),
            POINTER(c_int)]
        func.restype = c_char_p

        ret = c_bool(False)
        arg=c_int(0)

        result = func(
            self.obj,
            byref(ret),
            byref(arg)
        )

        if result:
            error_message = result.decode(sys.getdefaultencoding())
            print('Error:', error_message)
            raise TmException(error_message)

        return ret.value, arg.value
    
    def set_flat_feild_correction_mode(self,arg):
        if not self.obj:
            print('TmCamera object is not initialized!')
            return
        func=libTmCore.TmCtrl_SetFlatFieldCorrectionMode
        func.argtypes=[c_void_p,POINTER(c_bool),c_int]
        func.restype=c_char_p
        ret=c_bool(False)
        print("Calling TmCamera_SetFlatFeildCorrectionMode with:")
        print("self.obj:",self.obj)
        print("Parameters:",arg)
        result=func(self.obj,byref(ret),c_int(arg))
        if result:
            error_message=result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    def run_flat_field_correction(self):
        if not self.obj:
            print('TmCamera object is not initialized!')
            return
        func=libTmCore.TmCtrl_RunFlatFieldCorrection
        func.argtypes=[c_void_p,POINTER(c_bool)]
        func.restype=c_char_p
        ret=c_bool(False)
        print("Calling TmCamera_RunFlatFeildCorrection with:")
        print("self.obj:",self.obj)
        result=func(self.obj,byref(ret))
        if result:
            error_message=result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    
    def store_user_sensor_config(self):
        if not self.obj:
            print('TmCamera object is not initialized!')
            return
        func=libTmCore.TmCtrl_StoreUserSensorConfig
        func.argtypes=[c_void_p,POINTER(c_bool)]
        func.restype=c_char_p
        ret=c_bool(False)
        print("Calling TmCamera_StoreUserSensorConfig with:")
        print("self.obj:",self.obj)
        result=func(self.obj,byref(ret))
        if result:
            error_message=result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    
    def restore_default_sensor_config(self):
        if not self.obj:
            print('TmCamera object is not initialized!')
            return
        func=libTmCore.TmCtrl_RestoreDefaultSensorConfig
        func.argtypes=[c_void_p,POINTER(c_bool)]
        func.restype=c_char_p
        ret=c_bool(False)
        print("Calling TmCamera_StoreUserSensorConfig with:")
        print("self.obj:",self.obj)
        result=func(self.obj,byref(ret))
        if result:
            error_message=result.decode(sys.getdefaultencoding())
            raise TmException(error_message)
        return ret.value
    def get_network_configuration(self):
        if not self.obj:
            print("TmCamera object is not initialized!")
            return None

        max_string = 100
        mac = (c_char * max_string)()
        ip_assign = (c_char * max_string)()
        ip = (c_char * max_string)()
        netmask = (c_char * max_string)()
        gateway = (c_char * max_string)()
        dns = (c_char * max_string)()
        dns2 = (c_char * max_string)()

        func = libTmCore.TmCtrl_GetNetworkConfiguration
        func.argtypes = [
            c_void_p,
            POINTER(c_bool),
            POINTER(c_char * max_string),
            POINTER(c_char * max_string),
            POINTER(c_char * max_string),
            POINTER(c_char * max_string),
            POINTER(c_char * max_string),
            POINTER(c_char * max_string),
            POINTER(c_char * max_string)
        ]
        func.restype = c_char_p

        ret = c_bool(False)
        result = func(
            self.obj,
            byref(ret),
            pointer(mac),
            pointer(ip_assign),
            pointer(ip),
            pointer(netmask),
            pointer(gateway),
            pointer(dns),
            pointer(dns2)
        )

        if result:
            error_message = cast(result, c_char_p).value.decode(sys.getdefaultencoding())
            raise TmException(error_message)

        if not ret.value:
            print("TmCtrl_GetNetworkConfiguration failed!")
            return None

        return (
            mac.value.decode(sys.getdefaultencoding()),
            ip_assign.value.decode(sys.getdefaultencoding()),
            ip.value.decode(sys.getdefaultencoding()),
            netmask.value.decode(sys.getdefaultencoding()),
            gateway.value.decode(sys.getdefaultencoding()),
            dns.value.decode(sys.getdefaultencoding()),
            dns2.value.decode(sys.getdefaultencoding())
        )    
