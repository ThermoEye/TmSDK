### <summary>
### TmException
### </summary>
class TmException(Exception):
    def __init__(self, error):
        self.error = error

    def __str__(self):
        return self.value
    
    @staticmethod
    def ExceptionHandler(msg):
        if msg is None:
            return True
        else:
          raise TmException(msg)