import os, sys
from ctypes import *

from .TmException import *
from .TmTypes import *

from . import libTmCore

### <summary>
### RoiObject
### </summary>
class RoiObject(object):
    ### <summary>
    ### Ctor
    ### </summary>
    ### <param name="ptr"></param>
    def __init__(self):
        self.obj = c_void_p()
    def get_roi_type(self):
        func = libTmCore.TmRoiObject_GetRoiType
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(RoiType)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = RoiType(-1)
        ret = TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return arg.value
        
        
class RoiSpot(object):
    def __init__(self, *args):
        if len(args) == 0:
            func = libTmCore.TmRoiSpot_Ctor
            func.argtypes = ()
            func.restype = c_void_p
            self.obj = func()
        elif len(args) == 1 and isinstance(args[0], int):
            index = args[0]
            func = libTmCore.TmRoiSpot_Ctor_Index
            func.argtypes = [c_int]
            func.restype = c_void_p
            self.obj = func(index)
        elif len(args) == 1 and isinstance(args[0], Point):
            pt = args[0]
            func = libTmCore.TmRoiSpot_Ctor_Point
            func.argtypes = [Point]
            func.restype = c_void_p
            self.obj = func(pt)
        elif len(args) == 2 and all(isinstance(arg, int) for arg in args):
            x, y = args
            func = libTmCore.TmRoiSpot_Ctor_XY
            func.argtypes = [c_int, c_int]
            func.restype = c_void_p
            self.obj = func(x, y)
        elif len(args) == 3 and isinstance(args[0], int) and all(isinstance(arg, int) for arg in args[1:]):
            index, x, y = args
            func = libTmCore.TmRoiSpot_Ctor_IndexXY
            func.argtypes = [c_int, c_int, c_int]
            func.restype = c_void_p
            self.obj = func(index, x, y)
        elif len(args) == 1 and isinstance(args[0], RoiObject):
            roiObject = args[0]
            self.obj = roiObject.obj
        else:
            raise ValueError("Invalid arguments for RoiRect constructor")     

class RoiLine(object):
    def __init__(self, *args):
        if len(args) == 0:
            func = libTmCore.TmRoiLine_Ctor
            func.argtypes = ()
            func.restype = c_void_p
            self.obj = func()
        elif len(args) == 1 and isinstance(args[0], int):
            index = args[0]
            func = libTmCore.TmRoiLine_Ctor_Index
            func.argtypes = [c_int]
            func.restype = c_void_p
            self.obj = func(index)
        elif len(args) == 1 and isinstance(args[0], Point):
            pt = args[0]
            func = libTmCore.TmRoiLine_Ctor_Point
            func.argtypes = [Point]
            func.restype = c_void_p
            self.obj = func(pt)
        elif len(args) == 2 and all(isinstance(arg, int) for arg in args):
            x, y = args
            func = libTmCore.TmRoiLine_Ctor_XY
            func.argtypes = [c_int, c_int]
            func.restype = c_void_p
            self.obj = func(x, y)
        elif len(args) == 3 and isinstance(args[0], int) and all(isinstance(arg, int) for arg in args[1:]):
            index, x, y = args
            func = libTmCore.TmRoiLine_Ctor_IndexXY
            func.argtypes = [c_int, c_int, c_int]
            func.restype = c_void_p
            self.obj = func(index, x, y)
        elif len(args) == 1 and isinstance(args[0], RoiObject):
            roiObject = args[0]
            self.obj = roiObject.obj
        else:
            raise ValueError("Invalid arguments for RoiRect constructor")     

class RoiRect(object):
    def __init__(self, *args):
        if len(args) == 0:
            func = libTmCore.TmRoiRect_Ctor
            func.argtypes = ()
            func.restype = c_void_p
            self.obj = func()
        elif len(args) == 1 and isinstance(args[0], int):
            index = args[0]
            func = libTmCore.TmRoiRect_Ctor_Index
            func.argtypes = [c_int]
            func.restype = c_void_p
            self.obj = func(index)
        elif len(args) == 1 and isinstance(args[0], Point):
            pt = args[0]
            func = libTmCore.TmRoiRect_Ctor_Point
            func.argtypes = [Point]
            func.restype = c_void_p
            self.obj = func(pt)
        elif len(args) == 2 and all(isinstance(arg, int) for arg in args):
            x, y, w, h = args
            func = libTmCore.TmRoiRect_Ctor_XYWH
            func.argtypes = [c_int, c_int, c_int, c_int]
            func.restype = c_void_p
            self.obj = func(x, y, w, h)
        elif len(args) == 3 and isinstance(args[0], int) and all(isinstance(arg, int) for arg in args[1:]):
            index, x, y, w, h = args
            func = libTmCore.TmRoiRect_Ctor_IndexXYWH
            func.argtypes = [c_int, c_int, c_int, c_int, c_int]
            func.restype = c_void_p
            self.obj = func(index, x, y, w, h)
        elif len(args) == 1 and isinstance(args[0], RoiObject):
            roiObject = args[0]
            self.obj = roiObject.obj
        else:
            raise ValueError("Invalid arguments for RoiRect constructor")
        
    def get_rectangle(self):
        func = libTmCore.TmRoiRect_GetRectangle
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(Rectangle)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = Rectangle()
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return arg
### <summary>
### TmRoiManager
### </summary>
class TmRoiManager(object):
    ### <summary>
    ### Ctor
    ### </summary>
    ### <param name="ptr"></param>
    def __init__(self):
        func = libTmCore.TmRoi_Ctor
        func.argtypes = ()
        func.restype = c_void_p
        self.obj = func()
        # self.items = []
        
        
    ### <summary>
    ### Dispose of TmRoi
    ### </summary>
    def __del__(self):
        func = libTmCore.TmRoi_Dtor
        func.argtypes = [c_void_p]
        func.restype = None
        func(self.obj)
        
    def get_selected_roi_type(self):
        func = libTmCore.TmRoi_GetSelectedRoiType
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(arg)))
        return arg.value
    
    def set_selected_roi_type(self, arg):
        func = libTmCore.TmRoi_SetSelectedRoiType
        func.argtypes = [c_void_p, POINTER(c_bool), RoiType]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg))
        return ret.value
    
    def selected_item(self):
        func = libTmCore.TmRoi_SelectedItem
        func.argtypes = [c_void_p, POINTER(c_bool), c_void_p]
        func.restype = c_char_p
        ret = c_bool(False)
        arg = RoiObject()
        TmException.ExceptionHandler(func(self.obj, pointer(ret), arg.obj))
        return arg

    def roi_clear(self):
        func = libTmCore.TmRoi_Clear
        func.argtypes = [c_void_p, POINTER(c_bool)]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret)))
        return ret.value
    
    def mouse_down(self, pt):
        func = libTmCore.TmRoi_MouseDown
        func.argtypes = [c_void_p, POINTER(c_bool), Point]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pt))
        return ret.value
    
    def mouse_up(self, pt):
        func = libTmCore.TmRoi_MouseUp
        func.argtypes = [c_void_p, POINTER(c_bool), Point]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pt))
        return ret.value
    
    def mouse_move(self, pt):
        func = libTmCore.TmRoi_MouseMove
        func.argtypes = [c_void_p, POINTER(c_bool), Point]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pt))
        return ret.value

    def add_item_xy(self, type, x, y):
        func = libTmCore.TmRoi_AddItem_XY
        func.argtypes = [c_void_p, POINTER(c_bool), RoiType, c_int, c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), type, x, y))
        return ret.value
    
    def add_item_xywh(self, type, x, y, w, h):
        func = libTmCore.TmRoi_AddItem_XYWH
        func.argtypes = [c_void_p, POINTER(c_bool), RoiType, c_int, c_int, c_int, c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), type, x, y, w, h))
        return ret.value
    
    def remove_at(self, index):
        func = libTmCore.TmRoi_RemoveAt
        func.argtypes = [c_void_p, POINTER(c_bool), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), index))
        return ret.value

    def get_roi_item(self, index):
        func = libTmCore.TmRoi_GetItem
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_void_p), c_int]
        func.restype = c_char_p
        ret = c_bool(False)
        item = RoiObject()
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(item.obj), index))
        return item

    def get_roi_item_count(self):
        func = libTmCore.TmRoi_GetItemCount
        func.argtypes = [c_void_p, POINTER(c_bool), POINTER(c_int)]
        func.restype = c_char_p
        ret = c_bool(False)
        count = c_int(-1)
        TmException.ExceptionHandler(func(self.obj, pointer(ret), pointer(count)))
        return count.value
    
    def get_roi_type(self, index):
        func = libTmCore.TmRoi_GetRoiType
        func.argtypes = [c_void_p, POINTER(c_bool), c_int, POINTER(RoiType)]
        func.restype = c_char_p
        ret = c_bool(False)
        type = RoiType()
        TmException.ExceptionHandler(func(self.obj, pointer(ret), index, pointer(type)))
        return type.value
    