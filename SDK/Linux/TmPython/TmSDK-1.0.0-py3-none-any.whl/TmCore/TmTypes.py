import os, sys
from ctypes import *

class TempUnit(c_int):
    RAW = 0
    CELSIUS = 1
    FAHRENHEIT = 2
    KELVIN = 3
    
class ColormapTypes(c_int):
    GrayScale = -1
    Autumn = 0
    Bone = 1
    Jet = 2
    Winter = 3
    Rainbow = 4
    Ocean = 5
    Summer = 6
    Spring = 7
    Cool = 8
    Hsv = 9
    Pink = 10
    Hot = 11
    Parula = 12
    Magma = 13
    Inferno = 14
    Plasma = 15
    Viridis = 16
    Cividis = 17
    Twilight = 18
    TwilightShifted = 19
    Turbo = 20
    DeepGreen = 21
    
class RoiType(c_int):
    Hand = 0
    Spot = 1
    Line = 2
    Rect = 3
    Ellipse = 4
    
class Point(Structure):
    _fields_ = [
        ("x", c_int),
        ("y", c_int)
    ]
    def __init__(self, x = -1, y = -1):
        super(Point, self).__init__(x, y)
        
class Rectangle(Structure):
    _fields_ = [
        ("x", c_int),
        ("y", c_int),
        ("width", c_int),
        ("height", c_int),
    ]
    def __init__(self, x = -1, y = -1, w = -1, h = -1):
        super(Rectangle, self).__init__(x, y, w, h)

class LocItem(Structure):
    _fields_ = [
        ("value", c_double),
        ("location", Point),
    ]
    def __init__(self, value = 0.0, x = -1, y = -1 ):
        self.value = value
        self.location = Point(x, y)
